Pre-Requisites:
Windows Machine (logged into Microsoft account)
Node.js
Angular Cli Installed
MongoDB (with service installed for local hosting)
Admin Privileges

Procedure for installation:
1)Open Command Prompt in Admin mode
2)Change host ip in respective files:
->front end/src/main.service.ts
->front end/src/tc-navbar/tc-navbar-component.ts(loginUrl->hostIp)
3)Change Directory to any of the required Service (Backend or FrontEnd)
4)Run command : npm run-script install-windows-service
5)Service Installation should be completed

Uninstall Command:
1)Open Command Prompt in Admin mode
2)Change Directory to any of the required Service
3)Run command : npm run-script uninstall-windows-service


