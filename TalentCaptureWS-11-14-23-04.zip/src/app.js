const express = require('express');
const bodyParser = require('body-parser');
const router = require('./routes/routing');
const myErrorLogger = require('./utilities/errorlogger');
const myRequestLogger = require('./utilities/requestlogger');
const cors = require("cors")
const app = express();
const test= require('./routes/testRouting');
let login;
var corsOptions = {
  origin: [/^[http://localhost:4200]/],
  optionsSuccessStatus: 200,
  credentials:true
}
app.use(bodyParser.urlencoded({ extended: true }))
app.use(myRequestLogger);
app.use(bodyParser.json());
app.use(cors(corsOptions),function (req, res, next) {
    var nodeSSPI = require('node-sspi')
    var nodeSSPIObj = new nodeSSPI({
      retrieveGroups: true
    })
    nodeSSPIObj.authenticate(req, res, function(err){
      res.finished || next()
    })
})
// app.use('/login',function(req, res, next) {
//     var out =
//       req.connection.user;
//       next();
    
// })
// app.use('/login', router);

app.use('/test',test);
app.use('/', router);
app.use(myErrorLogger);


app.listen(1050);
console.log("Server listening in port 1050");


module.exports = app;