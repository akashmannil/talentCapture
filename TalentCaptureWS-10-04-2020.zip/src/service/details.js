const db = require('../model/details');
const validator = require('../utilities/validator');

let detailsService = {}


detailsService.getData = (id, test = false) => {
    return db.getData(id, test).then(obj => {
        if (obj) {
            return obj;
        }
        else {
            let err = new Error('User not Found');
            err.status = 404;
            throw err;
        }
    })
}


detailsService.addDetails = (details, test = false) => {
    return db.addDetails(details, test).then(value => {
        if (value)
            return value;
        else {
            let err = new Error('Data Write Error.Try Again Later');
            err.status = 500;
            throw err;
        }
    })
}


detailsService.updateDetails = (details, test = false) => {
    return db.updateDetails(details, test).then(value => {
        if (value)
            return value;
        else {
            let err = new Error('Updation Failed');
            err.status = 500;
            throw err;
        }
    })
}


detailsService.getDynamicData = (test = false) => {
    return db.getDynamicData(test).then(value => {
        if (value)
            return value;
        else {
            let err = new Error('Couldnt Fetch data');
            err.status = 500;
            throw err;
        }
    })
}


detailsService.getDashboardData = (empId = null, test = false) => {
    return db.getDashboardData(empId,test).then(value => {
        if (value)
            return value;
        else {
            let err = new Error("Some error Occured!");
            err.status=500;
            throw err;
        }
    })
}




module.exports = detailsService;