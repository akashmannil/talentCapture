const collection = require('../utilities/connection');
const dataGenerator=require('./generateData')
const detailsFile=require('./details')
const dynamicDatadb = [{

},]

generateData=()=>{}

exports.setupDb = (no,test=false) => {
    let accessDb=dataGenerator.readUsers()
    let detailsDb=dataGenerator.generateData(no);
    return collection.getAccessCollection(test).then((access) => {
        return access.deleteMany().then(() => {
            return access.insertMany(accessDb).then(() => {
                return collection.getDetailsCollection(test).then((details) => {
                    return details.deleteMany().then(() => {
                        return details.insertMany(detailsDb).then((data) => {
                            return collection.getDynamicDataCollection(test).then(dynamicData => {
                                return dynamicData.deleteMany().then(() => {
                                    return dynamicData.insertMany().then(data => {
                                        if (data) {
                                            detailsFile.setupDynamicData(test);
                                            return {message:"Insertion Successful"}}
                                        else {
                                            let err = new Error("Insertion failed");
                                            err.status = 400;
                                            throw err;
                                        }
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    })
}