import { Component, Injectable, Inject, OnInit } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MainService } from '../main.service';
import { HashPipe } from "../hash.pipe";
import { retry, catchError } from 'rxjs/operators';
@Component({
  selector: 'app-tc-navbar',
  templateUrl: './tc-navbar.component.html',
  styleUrls: ['./tc-navbar.component.css']
})
export class TcNavbarComponent implements OnInit {
  testButton: boolean = false;
  loginUrl = "http://localhost:1050/login/"
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
  notificationData: any = [];
  windowReload() {
    window.location.reload();
  }
  handleBrand() {
    if (this.loggedIn && (this.access == 'SuperAdmin' || this.access == 'Admin') && !this.trial) {
      document.getElementById('testButton').getAttribute('value')=='1'?document.getElementById('testButton').setAttribute('value','1'):
      document.getElementById('testButton').setAttribute('value','0')
      this.testButton = !this.testButton; this.test(); this.ngOnInit();
    }
  }
  loading = true;
  access;
  tryfn(){
    if(document.getElementById('welcomeButton').innerHTML=='LOGIN')
    this.serv.tryfn().subscribe(v=>{
    this.setupApp(v);
  },err=>this.openSnackBar(err.error.message,'Dismiss'))
  }
  ngOnInit() {
    let hash = new HashPipe();
    if (hash.transform(sessionStorage.getItem('accessType')) == 'SuperAdmin' ||
      hash.transform(sessionStorage.getItem('accessType')) == 'Admin') {
      this.serv.getNotifications().subscribe(value => {
        this.notificationData = value;
      })
    }
  }
  setupTest(a) {
    this.serv.tryfn1(a).subscribe(v=>{
      let hash=new HashPipe();
      this.setupApp(v);
    },err=>{this.openSnackBar(err.error.message,'Dismiss')})
  }
  setupTrial() {
    this.serv.tryfn1('SuperAdmin').subscribe(v=>{
      let hash=new HashPipe();
      document.getElementById('testButton').setAttribute('value','1');
      this.testButton=true;
      this.test(); 
      this.setupApp(v);
    },err=>{this.openSnackBar(err.error.message,'Dismiss')})
  }
  loggedIn = false;
  constructor(private breakpointObserver: BreakpointObserver, private router: Router, public dialog: MatDialog,
    private _snackBar: MatSnackBar, private serv: MainService) { }
  myWindow;
  login() {
    // document.getElementById('loginLink').click();
    // window.close();
    if (!this.access) {
      this.openWin();
      setTimeout(() => this.closeWin(), 1000);
      setTimeout(() => this.ngOnInit(), 1000);
    }
  }
  openWin(a = "") {
    this.myWindow = window.open(this.loginUrl + (a ? a : ""), "_blank", "width=300px, height=200px");
    setTimeout(() => this.closeWin(), 3000);
  }
  closeWin() {
    this.myWindow.close();
  }
  dashboard() {
    this.router.navigate(['/dashboard']);
  }
  addDetails() {
    this.router.navigate(['/addDetails']);
  }
  test() {
    document.getElementById('mynavbar').setAttribute('color', this.testButton ? 'warn' : 'primary');
    document.getElementById('mynavbar').setAttribute('class', this.testButton ?
      'mat-toolbar mat-warn mat-toolbar-single-row' : 'mat-toolbar mat-primary mat-toolbar-single-row');
    document.getElementById('myfooter').setAttribute('color', this.testButton ? 'warn' : 'primary');
    document.getElementById('myfooter').setAttribute('class', this.testButton ?
      'mat-toolbar mat-warn mat-toolbar-single-row' : 'mat-toolbar mat-primary mat-toolbar-single-row');
    document.getElementById('testButton').setAttribute('value', this.testButton ? '1' : '0');
    this.openSnackBar(`${this.testButton ? 'Testing Mode is enabled' : 'Connected to Main Servers!'}`, 'OK');
    this.redirectTo(this.router.url);
  }


  setupApp(v){
    Object.keys(v).forEach(v1 => {
      if (v1 == 'employeeId')
        sessionStorage.setItem('accessId', v[v1]);
      else if (v1 == 'emailId')
        sessionStorage.setItem('emailId', v[v1]);
      else if (v1 == 'accessType')
        sessionStorage.setItem('accessType', v[v1]);
    })
    let hash = new HashPipe();
    this.loggedIn = true;
    this.loading = false;
    this.access = hash.transform(sessionStorage.getItem('accessType'))
    document.getElementById('welcomeButton').innerHTML = (hash.transform(sessionStorage.getItem('accessId'))).toUpperCase();
    this.router.navigate(['/dashboard']);
    if (hash.transform(sessionStorage.getItem('accessType')) == 'SuperAdmin' ||
      hash.transform(sessionStorage.getItem('accessType')) == 'Admin') {
      this.serv.getNotifications().subscribe(value => {
        this.notificationData = value;
      })
  }
}



  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 1500,
      verticalPosition: 'top'
    });
  }
  openSnackBar1(message: any, action: string) {
    this._snackBar.open(message.message, action, {
      duration: 1500,
      verticalPosition: 'top'
    });
  }
  redirectTo(uri: string) {
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
      this.router.navigate([uri]));
  }
  trial:boolean=false;
  animal: string;
  name: string;
  openDialog(data): void {
    const dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '250px',
      data: { employeeName: data.employeeName, employeeId: data.employeeId, accessType: data.accessType, action: false }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result)
        this.serv.resolveRequest(result.employeeId, result.action).subscribe(value => {
          this.openSnackBar1(value, 'Dismiss');
          this.ngOnInit();
          this.redirectTo(this.router.url)
        }, err => {
          this.openSnackBar(err.error.message, 'Dismiss');
        })
    });
  }
}
@Component({
  selector: 'dialog-overview-example-dialog',
  templateUrl: './dialog.html',
})
export class DialogOverviewExampleDialog {

  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }


}