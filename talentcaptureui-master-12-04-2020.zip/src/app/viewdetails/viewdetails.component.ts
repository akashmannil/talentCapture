import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { MainService } from '../main.service';
@Component({
  selector: 'app-viewdetails',
  templateUrl: './viewdetails.component.html',
  styleUrls: ['./viewdetails.component.css']
})
export class ViewdetailsComponent implements OnInit {
  @Output()
  toggleButton:EventEmitter<any>=new EventEmitter();
  @Output()
  selectedUser:EventEmitter<any>=new EventEmitter();
  inputId;
  inputArr:Array<any>=[];
  sidenav;backbutton=true;//errror
  cardMargin={'margin-bottom':'35%'};
  dataArr:Array<any>=[];
isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
selectedArray:Array<any>=[];

  constructor(private router:Router,private breakpointObserver:BreakpointObserver,private serv:MainService) { }
  emitFn(){
    this.toggleButton.emit(true);
  }
  ngOnInit() {
  }
  onKey(e){
    if(e.key=="Enter"){
      this.inputArr.push(this.inputId);
      this.serv.viewDetails(this.inputId).subscribe(val=>{
        if(val){
        this.dataArr.push(val);
        this.dataArr=[...this.dataArr]
        }
        // console.log(this.dataArr);
      },err=>{console.log(err)})
      this.inputId=null;
      // this.searchDB();
    }
  }
  removeInput(value){
    this.inputArr=this.inputArr.filter(val=>val!=value)
    this.dataArr=this.dataArr.filter(val=>val.employeeId!=value)
    this.dataArr=this.dataArr.filter(val=>val.employeeName!=value)
    this.dataArr=this.dataArr.filter(val=>val.employeeEmail!=value)
    console.log(this.dataArr);
  }
  // searchDB(){
  //   this.selectedArray=this.dataArr.filter(value=>{
  //     let a=this.inputArr.filter(v=>v==value.employeeId||v.toLowerCase()==value.employeeName.toLowerCase()||
  //     v.toLowerCase()==value.employeeEmail.toLowerCase())
  //     return a.length;
  //   })
  //   console.log(this.selectedArray)
  // }


  displayedColumns: string[] = ['employeeId', 'employeeName', 'contactNo', 'totalExperience','actions'];

  log(e){
    console.log(e);
    this.router.navigate(['/dashboard',e.employeeId])
  }
  update(user){
    console.log("Update",user);
    this.selectedUser.emit(user);
  }

}


