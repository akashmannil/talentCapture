import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { ActivatedRoute } from '@angular/router';
import { MainService } from '../main.service';
import * as Chart from 'chart.js';

@Component({
  selector: 'app-my-dashboard',
  templateUrl: './my-dashboard.component.html',
  styleUrls: ['./my-dashboard.component.css']
})
export class MyDashboardComponent implements OnInit {
  appDashboard;
  detailsCardObject: any = { Entries: 0, SuperAdmin: 1, TotalAdmin: 1, TotalUsers: 2, jobLevelPlusRole: "Asd" };
  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true
  };

  public barChartOptions1= {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      xAxes: [
       {
           display: false
       }
     ],
      yAxes: [
         {
           display: true
       }
   ]
   }
  };
  public barChartLabels = ['2006', '2007', '2008', '2009', '2010', '2011', '2012'];
  public barChartType = 'bar';
  public barChartLegend = true;
  public barChartData = [
    { data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A' },
    { data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B' },
  ];
  projectAllocationData: any = [{}];
  projectAllocationLabel: any = [];
  jobData: any = [];
  jobLabel: any = [];
  jobLabel1: any = [];
  cardData: any = [{}];
  cardLabel: any = [];
  cardDataLabel: any = [];
  dataCardData: any = [];
  dataCardLabel: any = [];
  loading: boolean = true;
  public pieChartLabels = ['Sales Q1', 'Sales Q2', 'Sales Q3', 'Sales Q4'];
  public pieChartData = [120, 150, 180, 90];
  public pieChartType = 'pie';

  detailsCard1;
  cards1;
  /** Based on the screen size, switch from standard to one column per row */
  cards = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(({ matches }) => {
      if (matches) {
        return [{ title: 'Domain', cols: 4, rows: 1, myOrder: 1, name: 'domainAverage' },
        { title: 'PLC Skills', cols: 4, rows: 1, myOrder: 2, name: 'plcAverage' },
        { title: 'SCADA Skills', cols: 4, rows: 1, myOrder: 3, name: 'scadaAverage' },
        { title: 'DCS Skills', cols: 4, rows: 1, myOrder: 4, name: 'dcsAverage' },
        { title: 'HMI Skills', cols: 4, rows: 1, myOrder: 5, name: 'hmiAverage' }
        ];
      }

      return [{ title: 'Domain', cols: 1, rows: 1, myOrder: 1, name: 'domainAverage' },
      { title: 'PLC Skills', cols: 2, rows: 1, myOrder: 2, name: 'plcAverage' },
      { title: 'HMI Skills', cols: 1, rows: 1, myOrder: 5, name: 'hmiAverage' },
      { title: 'SCADA Skils', cols: 2, rows: 1, myOrder: 3, name: 'scadaAverage' },
      { title: 'DCS Skills', cols: 2, rows: 1, myOrder: 4, name: 'dcsAverage' }
      ];
    })
  );

  mobileView: boolean = false;
  detailsCard = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(({ matches }) => {
      let a: any = {}, b = [];
      if (matches && this.detailsCardObject.front) {
        Object.keys(this.detailsCardObject.front).forEach(v => {
          a = {}
          a.title = v;
          a.rows = 1;
          a.cols = 4;
          b.push(a);
        })
        this.mobileView = true;
        return b;
      }
      else if (!matches && this.detailsCardObject.front) {
        Object.keys(this.detailsCardObject.front).forEach(v => {
          a = {}
          a.title = v;
          a.rows = 1;
          a.cols = 1;
          b.push(a);
        })
        this.mobileView = false;
      }
      return b;
    })
  );
  constructor(private breakpointObserver: BreakpointObserver, private route: ActivatedRoute,
    private serv: MainService) {
  }
  ngOnInit() {
    this.route.params.subscribe(param => {
      this.appDashboard = param.id; console.log(this.appDashboard);
      this.serv.getDashboardData(this.appDashboard).subscribe(value => {
        this.detailsCardObject = value;
        console.log('mydata', this.detailsCardObject)
        this.detailsCard = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
          map(({ matches }) => {
            let a: any = {}, b = [];
            if (matches) {
              Object.keys(this.detailsCardObject.front).forEach(v => {
                a = {};
                a.title = v;
                a.rows = 1;
                a.cols = 4;
                b.push(a);
              })
              this.mobileView = true;
              return b;
            }
            Object.keys(this.detailsCardObject.front).forEach(v => {
              a = {}
              a.title = v;
              a.rows = 1;
              a.cols = 1;
              b.push(a);
            })
            this.mobileView = false;
            return b;
          })
        );
        this.projectAllocationData[0].data = Object.values(this.detailsCardObject.projectAllocation);
        this.projectAllocationData[0].label = "Percentage Allocation"
        this.projectAllocationLabel = Object.keys(this.detailsCardObject.projectAllocation);
        this.cardLabel = Object.keys(this.detailsCardObject).map(asd => {
          if (asd.indexOf('Average') > 0) {
            let a = [], b = [];
            this.detailsCardObject[asd].forEach(v => {
              b.push(Object.keys(v).map(val => val)[0]);
              a.push(Object.values(v).map(val => val)[0]);
            });
            this.cardDataLabel.push(b);
            this.cardData.push(a);
            return asd;
          }
        }).filter(v => v);
        console.log(this.cardLabel, ":", this.cardDataLabel, ":", this.cardData);

        let jd = { data: [], label: "No. of Employees" };
        this.detailsCardObject.jobLevelPlusRole.forEach(val => {
          this.jobLabel.push(val.jobLevelPlusRole[0] + " " + val.jobLevelPlusRole.substr(1));
          jd.data.push(val.count);
        })
        this.jobData.push(jd);
        this.jobLabel1 = this.jobLabel.map(v => {
          return v.split(' ').map(a => a[0]).join('')[0] + " " + v.split(' ').map(a => a[0]).join('').substr(1);
        })



        this.detailsCard1 = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
          map(({ matches }) => {
            let a: any = {}, b = [];
            if (matches) {
              b.push({ title: 'Employee Name', rows: 1, cols: 4, value: this.detailsCardObject.employee.employeeName },
                { title: 'Role', rows: 1, cols: 4, value: this.detailsCardObject.employee.currentRole },
                { title: 'Total Experience', rows: 1, cols: 4, value: this.detailsCardObject.employee.totalExperience + "yrs" },
                { title: 'Infosys Experience', rows: 1, cols: 4, value: this.detailsCardObject.employee.infosysExperience + "yrs" });
              this.mobileView = true;
              return b;
            }
            else {
              b.push({ title: 'Employee Name', rows: 1, cols: 1, value: this.detailsCardObject.employee.employeeName },
                { title: 'Role', rows: 1, cols: 1, value: this.detailsCardObject.employee.currentRole },
                { title: 'Total Experience', rows: 1, cols: 1, value: this.detailsCardObject.employee.totalExperience + "yrs" },
                { title: 'Infosys Experience', rows: 1, cols: 1, value: this.detailsCardObject.employee.infosysExperience + "yrs" })
            }
            this.mobileView = false;
            return b;
          })
        );
        if (this.detailsCardObject.employee) {
          let count = 0, a = [], b = [], c = [];
          this.detailsCardObject.employee.domain.forEach(dom => {
            count = 0;
            this.cardDataLabel[0].find(aa => {
              if (dom.selectedDomain == aa) {
                a.push(dom.experience);
                b.push(this.cardData[1][count])
                c.push(aa);
              }
              count += 1;
            })
          })
          this.dataCardData.push([{ data: a, label: "Experience(in yrs)" }, { data: b, label: "Infy Avg Experience(in yrs)" }]);
          this.dataCardLabel.push(c);

          a = [], b = [], c = [];
          this.detailsCardObject.employee.plcSkills.forEach(dom => {
            count = 0;
            this.cardDataLabel[1].find(aa => {
              if (dom.selectedPLC == aa) {
                a.push(dom.experience);
                b.push(this.cardData[2][count])
                c.push(aa);
              }
              count += 1;
            })
          })
          this.dataCardData.push([{ data: a, label: "Experience(in yrs)" }, { data: b, label: "Infy Avg Experience(in yrs)" }]);
          this.dataCardLabel.push(c);

          a = [], b = [], c = [];
          this.detailsCardObject.employee.scadaSkills.forEach(dom => {
            count = 0;
            this.cardDataLabel[2].find(aa => {
              if (dom.selectedSCADA == aa) {
                a.push(dom.experience);
                b.push(this.cardData[3][count])
                c.push(aa);
              }
              count += 1;
            })
          })
          this.dataCardData.push([{ data: a, label: "Experience(in yrs)" }, { data: b, label: "Infy Avg Experience(in yrs)" }]);
          this.dataCardLabel.push(c);

          a = [], b = [], c = [];
          this.detailsCardObject.employee.dcsSkills.forEach(dom => {
            count = 0;
            this.cardDataLabel[3].find(aa => {
              if (dom.selectedDCS == aa) {
                a.push(dom.experience);
                b.push(this.cardData[4][count])
                c.push(aa);
              }
              count += 1;
            })
          })
          this.dataCardData.push([{ data: a, label: "Experience(in yrs)" }, { data: b, label: "Infy Avg Experience(in yrs)" }]);
          this.dataCardLabel.push(c);


          a = [], b = [], c = [];
          this.detailsCardObject.employee.hmiSkills.forEach(dom => {
            count = 0;
            this.cardDataLabel[4].find(aa => {
              if (dom.selectedSCADA == aa) {
                a.push(dom.experience);
                b.push(this.cardData[5][count])
                c.push(aa);
              }
              count += 1;
            })
          })
          this.dataCardData.push([{ data: a, label: "Experience(in yrs)" }, { data: b, label: "Infy Avg Experience(in yrs)" }]);
          this.dataCardLabel.push(c);



          console.log(this.dataCardData, "DATA", this.dataCardLabel)



          this.cards1 = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
            map(({ matches }) => {
              if (matches) {
                return [{ title: 'Domain', cols: 6, rows: 1, myOrder: 1, name: 'domainAverage' },
                { title: 'PLC Skills', cols: 6, rows: 1, myOrder: 2, name: 'plcAverage' },
                { title: 'SCADA Skills', cols: 6, rows: 1, myOrder: 3, name: 'scadaAverage' },
                { title: 'DCS Skills', cols: 6, rows: 1, myOrder: 4, name: 'dcsAverage' },
                { title: 'HMI Skills', cols: 6, rows: 1, myOrder: 5, name: 'hmiAverage' }
                ];
              }

              return [{ title: 'Domain', cols: 2, rows: 1, myOrder: 1, name: 'domainAverage' },
              { title: 'PLC Skills', cols: 2, rows: 1, myOrder: 2, name: 'plcAverage' },
              { title: 'HMI Skills', cols: 2, rows: 1, myOrder: 5, name: 'hmiAverage' },
              { title: 'SCADA Skils', cols: 2, rows: 1, myOrder: 3, name: 'scadaAverage' },
              { title: 'DCS Skills', cols: 2, rows: 1, myOrder: 4, name: 'dcsAverage' }
              ];
            })
          );



        }
        this.loading = false;
      }, err => console.log(err))
    })
  }
}
