import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MainService {
  url:string="http://localhost:1050/"
  constructor(private http:HttpClient) { }

  addDetails(data){
    if(document.getElementById('testButton').getAttribute('value')=='0')
    return this.http.post(this.url+'details/add',data);
    return this.http.post(this.url+'test/'+'/details/add',data);
  }
  removeDetails(empId){
    if(document.getElementById('testButton').getAttribute('value')=='0')
    return this.http.delete(this.url+'delete/'+empId);
    return this.http.delete(this.url+'test/'+'delete/'+empId);
  }
  getDynamicData(){
    return this.http.get(this.url+'details/getdynamicdata')
  }
  setupTestDB(number){
    return this.http.get(this.url+'test/setupDb/'+(number-1))
  }
  getDashboardData(data=null){
    if(document.getElementById('testButton').getAttribute('value')=='0')
    return this.http.get(this.url+'details/dashboardData/'+data)
    return this.http.get(this.url+'test/details/dashboardData/'+data)
  }
  viewDetails(id){
    if(document.getElementById('testButton').getAttribute('value')=='0')
    return this.http.get(this.url+'details/'+id);
    return this.http.get(this.url+'test/details/'+id);
  }
  getNotifications(){
    if(document.getElementById('testButton').getAttribute('value')=='0')
    return this.http.get(this.url+'action/getnotifications/SuperAdmin');
    return this.http.get(this.url+'test/action/getnotifications/SuperAdmin');
  }
  resolveRequest(id,action){
    action=action?'approve':'reject';
    if(document.getElementById('testButton').getAttribute('value')=='0')
    return this.http.delete(this.url+'action/resolve/'+id+'/'+action);
    return this.http.delete(this.url+'test/action/resolve/'+id+'/'+action);
  }
  addRequest(data){
    if(document.getElementById('testButton').getAttribute('value')=='0')
    return this.http.post(this.url+'action/add',data);
    return this.http.post(this.url+'test/action/add',data);
  }
}

// redirectTo(uri:string){
//   this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
//   this.router.navigate([uri]));
// }
