import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServerofflineComponent } from './serveroffline.component';

describe('ServerofflineComponent', () => {
  let component: ServerofflineComponent;
  let fixture: ComponentFixture<ServerofflineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServerofflineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServerofflineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
