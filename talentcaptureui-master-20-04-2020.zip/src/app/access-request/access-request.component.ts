import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { MainService } from '../main.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HashPipe } from '../hash.pipe';
@Component({
  selector: 'app-access-request',
  templateUrl: './access-request.component.html',
  styleUrls: ['./access-request.component.css']
})
export class AccessRequestComponent implements OnInit {
  accessButton: boolean = false;
  addForm: FormGroup = this.fb.group({
    employeeId: ["", Validators.required],
    employeeName: ["", Validators.required],
    emailId: ["", Validators.required],
    accessType: ["", Validators.required]
  })
  user: any = {
    employeeId: "1111",
    employeeName: "Hello World",
    emailId: "helloworld@gmail.com",
    accessType: "SuperAdmin"
  };
  backbutton: boolean = false;
  @Output()
  toggleButton: EventEmitter<any> = new EventEmitter();
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
  constructor(private fb: FormBuilder, private breakpointObserver: BreakpointObserver,
    private ms: MainService, private _snackBar: MatSnackBar) { }

  ngOnInit() {
  }
  hash=new HashPipe();
  emitFn() {
    this.toggleButton.emit(true);
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
      verticalPosition: 'top'
    });
  }
  openSnackBar1(message: any, action: string) {
    this._snackBar.open(message.message, action, {
      duration: 2000,
      verticalPosition: 'top'
    });
  }
  onSubmit() {
    if(this.addForm.value.employeeId){
      this.user=false; 
    }
    if (!this.user) {
      this.ms.addRequest(this.addForm.value).subscribe(value => {
        this.openSnackBar1(value, 'Dismiss')
      },
        err => this.openSnackBar(err.message, 'Dismiss'))
    }
    else {
      this.user={
        employeeId: this.hash.transform(sessionStorage.getItem('accessId')),
        employeeName: this.hash.transform(sessionStorage.getItem('accessId')),
        emailId: this.hash.transform(sessionStorage.getItem('emailId')),
        accessType: this.addForm.value.accessType
      };
      // console.log(this.user)
      this.ms.addRequest(this.user).subscribe(value => {
        this.openSnackBar1(value, 'Dismiss')
      },
        err => {console.log(err);
          this.openSnackBar(err.error.message, 'Dismiss')})
    }
  }
}

