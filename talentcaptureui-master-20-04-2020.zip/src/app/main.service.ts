import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HashPipe } from './hash.pipe';

@Injectable({
  providedIn: 'root'
})
export class MainService {
  url: string = "http://localhost:1050/"
  constructor(private http: HttpClient) { }

  addDetails(data) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.post(this.url + 'details/add', data);
    return this.http.post(this.url + 'test/' + '/details/add', data);
  }
  getDetails(data) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'details/'+ data);
    return this.http.get(this.url + 'test/' + '/details/'+ data);
  }
  removeDetails(empId) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.delete(this.url + 'details/' + empId);
    return this.http.delete(this.url + 'test/' + 'details/' + empId);
  }
  updateDetails(user) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.put(this.url + 'details/update', user);
    return this.http.put(this.url + 'test/' + 'details/update', user);
  }
  getDynamicData() {
    return this.http.get(this.url + 'details/getdynamicdata')
  }
  setupTestDB(number) {
    return this.http.get(this.url + 'test/setupDb/' + (number - 1))
  }
  getDashboardData(data = null) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'details/dashboardData/' + data)
    return this.http.get(this.url + 'test/details/dashboardData/' + data)
  }
  viewDetails(id) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'details/' + id);
    return this.http.get(this.url + 'test/details/' + id);
  }
  getNotifications() {
    let hash = new HashPipe();
    if (document.getElementById('testButton').getAttribute('value') == '0') {
      if (hash.transform(sessionStorage.getItem('accessType')) == 'SuperAdmin')
        return this.http.get(this.url + 'action/getnotifications/SuperAdmin');
      else if (hash.transform(sessionStorage.getItem('accessType')) == 'Admin')
        return this.http.get(this.url + 'action/getnotifications/Admin');
    }
    else {
      if (hash.transform(sessionStorage.getItem('accessType')) == 'SuperAdmin')
        return this.http.get(this.url + 'test/action/getnotifications/SuperAdmin');
      else if (hash.transform(sessionStorage.getItem('accessType')) == 'Admin')
        return this.http.get(this.url + 'test/action/getnotifications/Admin');
    }

  }
  resolveRequest(id, action) {
    action = action ? 'approve' : 'reject';
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.delete(this.url + 'action/resolve/' + id + '/' + action);
    return this.http.delete(this.url + 'test/action/resolve/' + id + '/' + action);
  }
  addRequest(data) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.post(this.url + 'action/add', data);
    return this.http.post(this.url + 'test/action/add', data);
  }
  getAccessData(data) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'accessData/' + data);
    return this.http.get(this.url + 'test/accessData/' + data);
  }
  removeAccessData(data) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.delete(this.url + 'accessData/' + data);
    return this.http.delete(this.url + 'test/accessData/' + data);
  }
  getAllUsers() {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'getAllUsers/getAll');
    return this.http.get(this.url + 'test/getAllUsers/getAll');
  }
  getUser(type, id) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'getUser/' + type + '/' + id);
    return this.http.get(this.url + 'test/getUser/' + type + '/' + id);
  }
  getCurrentUser() {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'getCurrentUser/');
    return this.http.get(this.url + 'test/getCurrentUser/');
  }
}

// redirectTo(uri:string){
//   this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
//   this.router.navigate([uri]));
// }
