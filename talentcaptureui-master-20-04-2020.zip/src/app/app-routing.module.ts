import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddDetailsComponent } from './add-details/add-details.component';
import { LoginComponent } from './login/login.component';
import { MyDashboardComponent } from './my-dashboard/my-dashboard.component';
import { LoginGuard } from './login.guard';
import { ServerofflineComponent } from './serveroffline/serveroffline.component';


const routes: Routes = [
  {path:'',component:AddDetailsComponent},
  {path:"login",component:LoginComponent},
  {path:"addDetails",component:AddDetailsComponent},
  {path:"dashboard",component:MyDashboardComponent,canActivate:[LoginGuard]},
  {path:'dashboard/:id',component:MyDashboardComponent,canActivate:[LoginGuard]},
  {path:'503',component:ServerofflineComponent},
  {path:"**",pathMatch:'full',redirectTo:'/dashboard'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
