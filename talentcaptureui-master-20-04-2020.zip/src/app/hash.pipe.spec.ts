import { HashPipe } from './hash.pipe';

describe('HashPipe', () => {
  it('create an instance', () => {
    const pipe = new HashPipe();
    expect(pipe).toBeTruthy();
  });
});
