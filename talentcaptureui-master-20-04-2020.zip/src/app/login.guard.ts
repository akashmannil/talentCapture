import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { HashPipe } from './hash.pipe';

@Injectable({
  providedIn: 'root'
})
export class LoginGuard implements CanActivate {
  constructor(private router:Router){}
  canActivate() {
    let hash:HashPipe=new HashPipe();
    if(sessionStorage.getItem('accessType') && hash.transform(sessionStorage.getItem('accessType'))=='SuperAdmin'||hash.transform(sessionStorage.getItem('accessType'))=='Admin')
    return true;
    this.router.navigate(['/addDetails']);
  }
  
}
