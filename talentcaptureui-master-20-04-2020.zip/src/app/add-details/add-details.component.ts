import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { map, shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { MainService } from '../main.service';
import { HashPipe } from '../hash.pipe';
@Component({
  selector: 'app-add-details',
  templateUrl: './add-details.component.html',
  styleUrls: ['./add-details.component.css']
})
export class AddDetailsComponent implements OnInit {
  @Input()
  testButton: boolean;
  selectedUser;
  loading: boolean = true;
  backbutton: boolean;
  access;
  domainArray: Array<any> = [];
  plcSkillArray: Array<any> = [];
  scadaSkillArray: Array<any> = [];
  dcsSkillArray: Array<any> = [];
  hmiSkillArray: Array<any> = [];
  otherSkillArray: Array<any> = [];
  selectedDomain;
  customExp;
  selectedPLC;
  customExpPLC;
  selectedSCADA;
  customExpSCADA;
  selectedDCS;
  customExpDCS;
  selectedHMI;
  customExpHMI;
  selectedOther;
  customExpOther;
  totalExp;
  infyExp;
  cseExp;
  viewDetailsClicked; //error
  panelOpenState;
  receivedData: any;
  receiveData(e){
    this.selectedUser=e;
    this.updateClicked=!this.updateClicked;
    this.viewDetailsClicked=!this.viewDetailsClicked;
    console.log(this.selectedUser);
  }
  decryptHash(key){
    return this.hash.transform(sessionStorage.getItem(key))
  }
  handleAddDetails(){
    if(this.decryptHash('accessType')=='SuperAdmin' || this.decryptHash('accessType')=='Admin' || this.decryptHash('accessType')=='User'){
    this.ngOnInit();this.defaultClicked=true;this.viewAccess=false;this.selectedUser=null;
                this.updateClicked=false;this.viewDetailsClicked=false;}
    else{
      this.openSnackBar('Action not available for users','OK')
    }
  }
  handleViewDetails(){
    if(this.decryptHash('accessType')=='SuperAdmin' || this.decryptHash('accessType')=='Admin'){
      this.defaultClicked=false;this.selectedUser=null;
                this.updateClicked=false;this.viewDetailsClicked=true;}
      else{
        this.openSnackBar('Action not available for users','OK')
      }
  }
  handleUpdateDetails(){if(this.decryptHash('accessType')=='SuperAdmin' || this.decryptHash('accessType')=='Admin'){
    this.defaultClicked=false;this.viewAccess=false;this.selectedUser=null;
                this.updateClicked=true;this.viewDetailsClicked=false;}
    else{
      this.openSnackBar('Action not available for users','OK')
    }}
  handleSetupTesting(){
    if(this.decryptHash('accessType')=='SuperAdmin' || this.decryptHash('accessType')=='Admin'){
      this.viewAccess=false;this.selectedUser=null;this.handleSetup()}
      else{
        this.openSnackBar('Action not available for users','OK')
      }
  }

  addForm;
  onSubmit() {
    this.addForm.value.domain = this.domainArray;
    this.addForm.value.plcSkills = this.plcSkillArray;
    this.addForm.value.scadaSkills = this.scadaSkillArray;
    this.addForm.value.dcsSkills = this.dcsSkillArray;
    this.addForm.value.hmiSkills = this.hmiSkillArray;
    this.addForm.value.otherSkills = this.otherSkillArray;
    this.addForm.value.allocatedToProject={
      name:this.addForm.value.allocatedToProject,
      allocation: (this.addForm.value.allocatedToProject)? true:false,
      percentageAllocation:this.addForm.value.percentageAllocation
    };
    console.log(this.addForm.value);
    this.mainService.addDetails(this.addForm.value).subscribe(value => {
      this.openSnackBar('Data Added Successfully','Dismiss');
    }, err => this.openSnackBar(err.message,'Dismiss'))
  }
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
  defaultClicked: boolean = true;
  updateClicked: boolean = false;
  viewDetals: boolean = false;
  constructor(private fb: FormBuilder, private _snackBar: MatSnackBar, private breakpointObserver: BreakpointObserver,
    private mainService: MainService,private router:Router) {
  }
  sortData() {
    this.receivedData.domain.sort();
    this.receivedData.domain=this.receivedData.domain.filter(_=>_!='other'&&_!='Other'&&_!='Others'&&_!='NA')
    this.receivedData.plcSkills=this.receivedData.plcSkills.filter(_=>_!='other'&&_!='Other'&&_!='Others'&&_!='NA')
    this.receivedData.scadaSkills=this.receivedData.scadaSkills.filter(_=>_!='other'&&_!='Other'&&_!='Others'&&_!='NA')
    this.receivedData.hmiSkills=this.receivedData.hmiSkills.filter(_=>_!='other'&&_!='Other'&&_!='Others'&&_!='NA')
    this.receivedData.dcsSkills=this.receivedData.dcsSkills.filter(_=>_!='other'&&_!='Other'&&_!='Others'&&_!='NA')
    this.receivedData.otherSkills=this.receivedData.otherSkills.filter(_=>_!='other'&&_!='Other'&&_!='Others'&&_!='NA')
    this.receivedData.plcSkills.sort();
    this.receivedData.scadaSkills.sort();
    this.receivedData.dcsSkills.sort();
    this.receivedData.hmiSkills.sort();
    this.receivedData.otherSkills.sort();
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
      verticalPosition: 'top'
    });
  }
  childToggle(e) {
    // console.log("Called :",e);
    e.toggle();
  }
  poppedDomain;
  addDomain() {
    // console.log(this.domainArray);
    this.domainArray.push({ domain: this.addForm.value.selectedDomain, experience: this.addForm.value.customExp });
    this.receivedData.domain=this.receivedData.domain.filter(v=>v!=this.addForm.value.selectedDomain);
  }
  removeDomain(domain) {
    this.domainArray = this.domainArray.filter(value => value.domain != domain);
    // console.log(domain, ":", this.domainArray);
    this.receivedData.domain.push(domain);
    this.receivedData.domain.sort();
  }
  addPLCSkill() {
    this.plcSkillArray.push({ plcSkill: this.addForm.value.selectedPLC, experience: this.addForm.value.customExpPLC });
    this.receivedData.plcSkills=this.receivedData.plcSkills.filter(v=>v!=this.addForm.value.selectedPLC);
  }
  removePLCSkill(skill) {
    this.plcSkillArray = this.plcSkillArray.filter(value => skill != value.plcSkill);
    this.receivedData.plcSkills.push(skill);
    this.receivedData.plcSkills.sort();
  }
  addSCADASkill() {
    this.scadaSkillArray.push({ scadaSkill: this.addForm.value.selectedSCADA, experience: this.addForm.value.customExpSCADA })
    this.receivedData.scadaSkills=this.receivedData.scadaSkills.filter(v=>v!=this.addForm.value.selectedSCADA);  
  }
  removeSCADASkill(skill) {
    this.scadaSkillArray = this.scadaSkillArray.filter(value => skill != value.scadaSkill);
    this.receivedData.scadaSkills.push(skill);
    this.receivedData.scadaSkills.sort();
  }
  addDCSSkill() {
    this.dcsSkillArray.push({ dcsSkill: this.addForm.value.selectedDCS, experience: this.addForm.value.customExpDCS });
    this.receivedData.dcsSkills=this.receivedData.dcsSkills.filter(v=>v!=this.addForm.value.selectedDCS);  
  }
  removeDCSSkill(skill) {
    this.dcsSkillArray = this.dcsSkillArray.filter(value => skill != value.dcsSkill);
    this.receivedData.dcsSkills.push(skill);
    this.receivedData.dcsSkills.sort();
  }
  addHMISkill() {
    this.hmiSkillArray.push({ hmiSkill: this.addForm.value.selectedHMI, experience: this.addForm.value.customExpHMI });
    this.receivedData.hmiSkills=this.receivedData.hmiSkills.filter(v=>v!=this.addForm.value.selectedHMI);
  }
  removeHMISkill(skill) {
    this.hmiSkillArray = this.hmiSkillArray.filter(value => skill != value.hmiSkill);
    this.receivedData.hmiSkills.push(skill);
    this.receivedData.hmiSkills.sort();
  }
  addOtherSkill() {
    this.otherSkillArray.push({ otherSkill: this.addForm.value.selectedOther, experience: this.addForm.value.customExpOther })
    this.receivedData.otherSkills=this.receivedData.otherSkills.filter(v=>v!=this.addForm.value.selectedOther);

  }
  removeOtherSkill(skill) {
    this.otherSkillArray = this.otherSkillArray.filter(value => skill != value.otherSkill);
    this.receivedData.otherSkills.push(skill);
    this.receivedData.otherSkills.sort();
  }
  hash:HashPipe=new HashPipe();
  ngOnInit() {
    this.addForm = this.fb.group({
      employeeId: ["", Validators.required],
      employeeName: ["", Validators.required],
      employeeEmail: ["", Validators.required],
      contactNo: ["",[ Validators.required, Validators.min(1000000000), Validators.max(9999999999)]],
      jobLevel: ["", Validators.required],
      currentRole: ["", Validators.required],
      totalExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
      infosysExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
      controlSystemExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
      allocatedToProject: [{value:"",disabled:true}],
      percentageAllocation: [{value:"",disabled:true}],
      selectedDomain: [""],
      customExp: [""],
      selectedPLC: [""],
      customExpPLC: [""],
      selectedSCADA: [""],
      customExpSCADA: [""],
      selectedDCS: [""],
      customExpDCS: [""],
      selectedHMI: [""],
      customExpHMI: [""],
      selectedOther: [""],
      customExpOther: [""]
  
    });
    this.mainService.getDynamicData().subscribe(value => {
      console.log(value);
      this.receivedData = value;
      this.sortData();if(this.decryptHash('accessType')=='SuperAdmin'){

        this.addForm = this.fb.group({
          employeeId: ["", Validators.required],
          employeeName: ["", Validators.required],
          employeeEmail: ["", Validators.required],
          contactNo: ["",[ Validators.required, Validators.min(1000000000), Validators.max(9999999999)]],
          jobLevel: ["", Validators.required],
          currentRole: ["", Validators.required],
          totalExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
          infosysExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
          controlSystemExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
          allocatedToProject: [""],
          percentageAllocation: [""],
          selectedDomain: [""],
          customExp: [""],
          selectedPLC: [""],
          customExpPLC: [""],
          selectedSCADA: [""],
          customExpSCADA: [""],
          selectedDCS: [""],
          customExpDCS: [""],
          selectedHMI: [""],
          customExpHMI: [""],
          selectedOther: [""],
          customExpOther: [""]
      
        });

      }
    }, err =>{ console.log(err);
    if(err.status==0){this.router.navigate(['/asdasd']);}})
    setTimeout(() => this.loading = false, 2000);
    this.access=this.hash.transform(sessionStorage.getItem('accessType'));
  }
  formatLabelPercentage(value: number) {
    return value + '%'
  }
  formatLabelYears(value: number) {
    return value + "y"
  }
  viewAccess:boolean=false;
  handleSetup(){
    if(document.getElementById('testButton').getAttribute('value')=='0'){
      this.openSnackBar('Please enable test mode to access this','OK')
      this.defaultClicked=true;
      this.updateClicked=false;
      this.viewDetailsClicked=false;
    }
    else{
      this.defaultClicked=false;
      this.updateClicked=false;
      this.viewDetailsClicked=false;
    }
  }
}
