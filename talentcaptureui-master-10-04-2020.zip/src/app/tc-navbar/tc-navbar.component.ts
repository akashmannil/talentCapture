import { Component, Injectable, Inject } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

export interface DialogData {
  animal: string;
  name: string;
}

@Component({
  selector: 'app-tc-navbar',
  templateUrl: './tc-navbar.component.html',
  styleUrls: ['./tc-navbar.component.css']
})
export class TcNavbarComponent {
  testButton:boolean=false;
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

  constructor(private breakpointObserver: BreakpointObserver,private router:Router,public dialog: MatDialog,
    private _snackBar:MatSnackBar) {}
  login(){
    this.router.navigate(['/login']);
  }
  dashboard(){
    this.router.navigate(['/dashboard']);
  }
  addDetails(){
    this.router.navigate(['/addDetails']);
  }
  test(){
    document.getElementById('mynavbar').setAttribute('color',this.testButton?'warn':'primary');
    document.getElementById('mynavbar').setAttribute('class',this.testButton?
    'mat-toolbar mat-warn mat-toolbar-single-row':'mat-toolbar mat-primary mat-toolbar-single-row');
    document.getElementById('myfooter').setAttribute('color',this.testButton?'warn':'primary');
    document.getElementById('myfooter').setAttribute('class',this.testButton?
    'mat-toolbar mat-warn mat-toolbar-single-row':'mat-toolbar mat-primary mat-toolbar-single-row');
    document.getElementById('testButton').setAttribute('value',this.testButton?'1':'0');
    // console.log(document.getElementById('mynavbar'))
    // console.log(document.getElementById('testButton').getAttribute('value'))
    this.openSnackBar(`${this.testButton?'Testing Mode is enabled':'Connected to Main Servers!'}`,'OK');
    this.redirectTo(this.router.url)
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 1500,
      verticalPosition: 'top'
    });
  }
  redirectTo(uri:string){
  this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
  this.router.navigate([uri]));
}
animal: string;
name: string;
openDialog(): void {
  const dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
    width: '250px',
    data: {name: this.name, animal: this.animal}
  });

  dialogRef.afterClosed().subscribe(result => {
    console.log('The dialog was closed');
    this.animal = result;
  });
}
}
@Component({
  selector: 'dialog-overview-example-dialog',
  templateUrl: './dialog.html',
})
export class DialogOverviewExampleDialog {

  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {

    this.dialogRef.close();
  }
  approveReq():void{
    console.log("asdasd")
  }

}