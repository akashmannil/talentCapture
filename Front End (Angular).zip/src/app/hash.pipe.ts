import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'hash'
})
export class HashPipe implements PipeTransform {

  transform(value): any {
    if (value) {
      let key = Number(Number(value.split('k')[1]));
      let subtr = Number(value.split('k')[2])
      let count = -1;
      return value.split('k')[0].split('a').map(a => {
        return String.fromCharCode(subtr - Number(a) + key + (count += 1))
      }).join('');
    }
  }
  transfrom1(value):any{
    if (value) {
      let key = Math.floor(Math.random() * 1000) + 1;
    let subtr = Math.floor(Math.random() * 1000) + 1;
    let count = -1;
    return value.split('').map(() => {
        return Number(subtr - value.charCodeAt(count += 1)) + key + count
    }).join('a') + 'k' + key + 'k' + subtr;
    }
  }

}
