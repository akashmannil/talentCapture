import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { MainService } from '../main.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HashPipe } from '../hash.pipe';

@Component({
  selector: 'app-updatedetails',
  templateUrl: './updatedetails.component.html',
  styleUrls: ['./updatedetails.component.css']
})
export class UpdatedetailsComponent implements OnInit {
  @Input()
  userDetails;
  @Output()
  toggleButton: EventEmitter<any> = new EventEmitter();
  domainArray: Array<any> = [];
  plcSkillArray: Array<any> = [];
  scadaSkillArray: Array<any> = [];
  dcsSkillArray: Array<any> = [];
  hmiSkillArray: Array<any> = [];
  otherSkillArray: Array<any> = [];
  selectedDomain;
  customExp;
  selectedPLC;
  customExpPLC;
  selectedSCADA;
  customExpSCADA;
  selectedDCS;
  customExpDCS;
  selectedHMI;
  customExpHMI;
  selectedOther;
  customExpOther;
  sidenav; backbutton; totalExp; infyExp; cseExp;//error
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
  hash: HashPipe = new HashPipe();
  domain = ['infrastructure top-level domain (ARPA)'
    , 'generic top-level domains (gTLD)'
    , 'generic-restricted top-level domains (grTLD)'
    , 'sponsored top-level domains (sTLD)'
    , 'country code top-level domains (ccTLD)'
    , 'test top-level domains (tTLD)']
  addForm = this.fb.group({
    employeeId: ["", Validators.required],
    employeeName: ["", Validators.required],
    employeeEmail: ["", [Validators.required,Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/)]],
    contactNo: ["", Validators.required],
    jobLevel: ["", Validators.required],
    currentRole: ["", Validators.required],
    totalExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
    infosysExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
    controlSystemExperience: ["", [Validators.required, Validators.min(1), Validators.max(5)]],
    allocatedToProject: [{ value: '', disabled: true }, Validators.required],
    percentageAllocation: [{ value: '', disabled: true }, Validators.required],
    selectedDomain: [""],
    customExp: [""],
    selectedPLC: [""],
    customExpPLC: [""],
    selectedSCADA: [""],
    customExpSCADA: [""],
    selectedDCS: [""],
    customExpDCS: [""],
    selectedHMI: [""],
    customExpHMI: [""],
    selectedOther: [""],
    customExpOther: [""],
    otherDomain: [""],
    otherDomainExp: [""],
    otherPLC: [""],
    otherPLCExp: [""],
    otherSCADA: [""],
    otherSCADAExp: [""],
    otherHMI: [""],
    otherHMIExp: [""],
    otherDCS: [""],
    otherDCSExp: [""],
    otherOTHER: [""],
    otherOTHERExp: [""],
  });
  emitFn() {
    this.toggleButton.emit(true);
  }
  onSubmit() {
    this.addForm.value.domain = this.domainArray;
    this.addForm.value.plcSkills = this.plcSkillArray;
    this.addForm.value.scadaSkills = this.scadaSkillArray;
    this.addForm.value.dcsSkills = this.dcsSkillArray;
    this.addForm.value.hmiSkills = this.hmiSkillArray;
    this.addForm.value.otherSkills = this.otherSkillArray;
    this.addForm.value.allocatedToProject = {
      name: this.addForm.value.allocatedToProject,
      allocation: (this.addForm.value.allocatedToProject) ? true : false,
      percentageAllocation: this.addForm.value.percentageAllocation
    };
    this.mainService.updateDetails(this.addForm.value).subscribe(value => {
      this.openSnackBar(value, 'Dismiss');
      this.redirectTo(this.router.url);
    }, err => { this.openSnackBar1(err.error.message, 'Dismiss') }
    )
  }
  redirectTo(uri: string) {
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
      this.router.navigate([uri]));
  }

  constructor(private fb: FormBuilder, private breakpointObserver: BreakpointObserver, private mainService: MainService,
    private router: Router, private _snackBar: MatSnackBar) {
  }
  receivedData: any;
  sortData() {
    this.receivedData.domain.sort();
    this.receivedData.domain = this.receivedData.domain.filter(_ => _ != 'other' && _ != 'Other' && _ != 'Others' && _ != 'NA')
    this.receivedData.plcSkills = this.receivedData.plcSkills.filter(_ => _ != 'other' && _ != 'Other' && _ != 'Others' && _ != 'NA')
    this.receivedData.scadaSkills = this.receivedData.scadaSkills.filter(_ => _ != 'other' && _ != 'Other' && _ != 'Others' && _ != 'NA')
    this.receivedData.hmiSkills = this.receivedData.hmiSkills.filter(_ => _ != 'other' && _ != 'Other' && _ != 'Others' && _ != 'NA')
    this.receivedData.dcsSkills = this.receivedData.dcsSkills.filter(_ => _ != 'other' && _ != 'Other' && _ != 'Others' && _ != 'NA')
    this.receivedData.otherSkills = this.receivedData.otherSkills.filter(_ => _ != 'other' && _ != 'Other' && _ != 'Others' && _ != 'NA')
    this.receivedData.plcSkills.sort();
    this.receivedData.scadaSkills.sort();
    this.receivedData.dcsSkills.sort();
    this.receivedData.hmiSkills.sort();
    this.receivedData.otherSkills.sort();
    this.receivedData.domain.push('Others');
    this.receivedData.scadaSkills.push('Others');
    this.receivedData.plcSkills.push('Others');
    this.receivedData.hmiSkills.push('Others');
    this.receivedData.dcsSkills.push('Others');
    this.receivedData.otherSkills.push('Others');

  }

  addDomain(custom = false) {
    if (!custom) {
      this.domainArray.push({ domain: this.addForm.value.selectedDomain, experience: this.addForm.value.customExp });
      this.receivedData.domain = this.receivedData.domain.filter(v => v != this.addForm.value.selectedDomain);
    }
    else {
      this.domainArray.push({ domain: this.addForm.value.otherDomain, experience: this.addForm.value.otherDomainExp });
    }
    this.addForm.value.otherDomain = null;
  }
  removeDomain(domain) {
    this.domainArray = this.domainArray.filter(value => value.domain != domain);
    if (this.receivedDataCopy.domain.find(v => v == domain)) {
      this.receivedData.domain.push(domain);
      this.receivedData.domain.sort();
    }
  }
  addPLCSkill(custom = false) {
    if (!custom) {
      this.plcSkillArray.push({ plcSkill: this.addForm.value.selectedPLC, experience: this.addForm.value.customExpPLC });
      this.receivedData.plcSkills = this.receivedData.plcSkills.filter(v => v != this.addForm.value.selectedPLC);
    }
    else
      this.plcSkillArray.push({ plcSkill: this.addForm.value.otherPLC, experience: this.addForm.value.otherPLCExp });

  }
  removePLCSkill(skill) {
    this.plcSkillArray = this.plcSkillArray.filter(value => skill != value.plcSkill);
    if (this.receivedDataCopy.plcSkills.find(v => v == skill)) {
      this.receivedData.plcSkills.push(skill);
      this.receivedData.plcSkills.sort();
    }
  }
  addSCADASkill(custom = false) {
    if (!custom) {
      this.scadaSkillArray.push({ scadaSkill: this.addForm.value.selectedSCADA, experience: this.addForm.value.customExpSCADA })
      this.receivedData.scadaSkills = this.receivedData.scadaSkills.filter(v => v != this.addForm.value.selectedSCADA);
    }
    else
      this.scadaSkillArray.push({ scadaSkill: this.addForm.value.otherSCADA, experience: this.addForm.value.otherSCADAExp });

  }
  removeSCADASkill(skill) {
    this.scadaSkillArray = this.scadaSkillArray.filter(value => skill != value.scadaSkill);
    if (this.receivedDataCopy.scadaSkills.find(v => v == skill)) {
      this.receivedData.scadaSkills.push(skill);
      this.receivedData.scadaSkills.sort();
    }
  }
  addDCSSkill(custom = false) {
    if (!custom) {
      this.dcsSkillArray.push({ dcsSkill: this.addForm.value.selectedDCS, experience: this.addForm.value.customExpDCS });
      this.receivedData.dcsSkills = this.receivedData.dcsSkills.filter(v => v != this.addForm.value.selectedDCS);
    }
    else
      this.dcsSkillArray.push({ dcsSkill: this.addForm.value.otherDCS, experience: this.addForm.value.otherDCSExp });
  }
  removeDCSSkill(skill) {
    this.dcsSkillArray = this.dcsSkillArray.filter(value => skill != value.dcsSkill);
    if (this.receivedDataCopy.dcsSkills.find(v => v == skill)) {
      this.receivedData.dcsSkills.push(skill);
      this.receivedData.dcsSkills.sort();
    }
  }
  addHMISkill(custom = false) {
    if (!custom) {
      this.hmiSkillArray.push({ hmiSkill: this.addForm.value.selectedHMI, experience: this.addForm.value.customExpHMI });
      this.receivedData.hmiSkills = this.receivedData.hmiSkills.filter(v => v != this.addForm.value.selectedHMI);
    }
    else
      this.hmiSkillArray.push({ hmiSkill: this.addForm.value.otherHMI, experience: this.addForm.value.otherHMIExp });

  }
  removeHMISkill(skill) {
    this.hmiSkillArray = this.hmiSkillArray.filter(value => skill != value.hmiSkill);
    if (this.receivedDataCopy.hmiSkills.find(v => v == skill)) {
      this.receivedData.hmiSkills.push(skill);
      this.receivedData.hmiSkills.sort();
    }
  }
  addOtherSkill(custom = false) {
    if (!custom) {
      this.otherSkillArray.push({ otherSkill: this.addForm.value.selectedOther, experience: this.addForm.value.customExpOther })
      this.receivedData.otherSkills = this.receivedData.otherSkills.filter(v => v != this.addForm.value.selectedOther);
    }
    else
      this.otherSkillArray.push({ otherSkill: this.addForm.value.otherOTHER, experience: this.addForm.value.otherOTHERExp });
  }
  removeOtherSkill(skill) {
    this.otherSkillArray = this.otherSkillArray.filter(value => skill != value.otherSkill);
    if (this.receivedDataCopy.otherSkills.find(v => v == skill)) {
      this.receivedData.otherSkills.push(skill);
      this.receivedData.otherSkills.sort();
    }
  }
  decryptHash(key) {
    return this.hash.transform(sessionStorage.getItem(key))
  }
  filterData() {
    this.receivedData.domain = this.receivedData.domain.filter(v => {
      let t = 1;
      this.userDetails.domain.forEach(asd => {
        if (asd.domain == v) { t = 0 }
      })
      return t;
    });
    this.receivedData.plcSkills = this.receivedData.plcSkills.filter(v => {
      let t = 1;
      this.userDetails.plcSkills.forEach(asd => {
        if (asd.plcSkills == v) { t = 0 }
      })
      return t;
    });
    this.receivedData.scadaSkills = this.receivedData.scadaSkills.filter(v => {
      let t = 1;
      this.userDetails.scadaSkills.forEach(asd => {
        if (asd.scadaSkills == v) { t = 0 }
      })
      return t;
    });
    this.receivedData.dcsSkills = this.receivedData.dcsSkills.filter(v => {
      let t = 1;
      this.userDetails.dcsSkills.forEach(asd => {
        if (asd.dcsSkills == v) { t = 0 }
      })
      return t;
    });
    this.receivedData.hmiSkills = this.receivedData.hmiSkills.filter(v => {
      let t = 1;
      this.userDetails.hmiSkills.forEach(asd => {
        if (asd.hmiSkills == v) { t = 0 }
      })
      return t;
    }); this.receivedData.otherSkills = this.receivedData.otherSkills.filter(v => {
      let t = 1;
      this.userDetails.otherSkills.forEach(asd => {
        if (asd.otherSkills == v) { t = 0 }
      })
      return t;
    });
  }
  receivedDataCopy;
  ngOnInit() {
    this.mainService.getDynamicData().subscribe(value => {
      this.receivedDataCopy = {};
      this.receivedData = value;
      this.receivedDataCopy.domain = this.receivedData.domain;
      this.receivedDataCopy.plcSkills = this.receivedData.plcSkills;
      this.receivedDataCopy.dcsSkills = this.receivedData.dcsSkills;
      this.receivedDataCopy.scadaSkills = this.receivedData.scadaSkills;
      this.receivedDataCopy.hmiSkills = this.receivedData.hmiSkills;
      this.receivedDataCopy.otherSkills = this.receivedData.otherSkills;
      this.sortData();
      if (this.userDetails && this.decryptHash('accessType') == 'SuperAdmin') {
        this.domainArray = this.userDetails.domain;
        this.plcSkillArray = this.userDetails.plcSkills;
        this.scadaSkillArray = this.userDetails.scadaSkills;
        this.dcsSkillArray = this.userDetails.dcsSkills;
        this.hmiSkillArray = this.userDetails.hmiSkills;
        this.otherSkillArray = this.userDetails.otherSkills;
        this.addForm = this.fb.group({
          employeeId: [this.userDetails.employeeId, Validators.required],
          employeeName: [this.userDetails.employeeName, Validators.required],
          employeeEmail: ["", [Validators.required,Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/)]],
          contactNo: [this.userDetails.contactNo, Validators.required],
          jobLevel: [this.userDetails.jobLevel, Validators.required],
          currentRole: [this.userDetails.currentRole, Validators.required],
          totalExperience: [this.userDetails.totalExperience, [Validators.required, Validators.min(1), Validators.max(10)]],
          infosysExperience: [this.userDetails.infosysExperience, [Validators.required, Validators.min(1), Validators.max(10)]],
          controlSystemExperience: [this.userDetails.controlSystemExperience, [Validators.required, Validators.min(1), Validators.max(5)]],
          allocatedToProject: [(this.userDetails.allocatedToProject.allocation) ? this.userDetails.allocatedToProject.projectName : "",
          Validators.required],
          percentageAllocation: [{
            value: (this.userDetails.allocatedToProject.allocation) ? this.userDetails.allocatedToProject.percentageAllocation : "",
            disabled: false
          }],
          selectedDomain: [""],
          customExp: [""],
          selectedPLC: [""],
          customExpPLC: [""],
          selectedSCADA: [""],
          customExpSCADA: [""],
          selectedDCS: [""],
          customExpDCS: [""],
          selectedHMI: [""],
          customExpHMI: [""],
          selectedOther: [""],
          customExpOther: [""],
          otherDomain: [""],
          otherDomainExp: [""],
          otherPLC: [""],
          otherPLCExp: [""],
          otherSCADA: [""],
          otherSCADAExp: [""],
          otherHMI: [""],
          otherHMIExp: [""],
          otherDCS: [""],
          otherDCSExp: [""],
          otherOTHER: [""],
          otherOTHERExp: [""],
        });
        this.filterData();
      }
      else if (this.userDetails && this.decryptHash('accessType') == 'Admin') {
        this.domainArray = this.userDetails.domain;
        this.plcSkillArray = this.userDetails.plcSkills;
        this.scadaSkillArray = this.userDetails.scadaSkills;
        this.dcsSkillArray = this.userDetails.dcsSkills;
        this.hmiSkillArray = this.userDetails.hmiSkills;
        this.otherSkillArray = this.userDetails.otherSkills;
        this.addForm = this.fb.group({
          employeeId: [this.userDetails.employeeId, Validators.required],
          employeeName: [this.userDetails.employeeName, Validators.required],
          employeeEmail: ["", [Validators.required,Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/)]],
          contactNo: [this.userDetails.contactNo, Validators.required],
          jobLevel: [this.userDetails.jobLevel, Validators.required],
          currentRole: [this.userDetails.currentRole, Validators.required],
          totalExperience: [this.userDetails.totalExperience, [Validators.required, Validators.min(1), Validators.max(10)]],
          infosysExperience: [this.userDetails.infosysExperience, [Validators.required, Validators.min(1), Validators.max(10)]],
          controlSystemExperience: [this.userDetails.controlSystemExperience, [Validators.required, Validators.min(1), Validators.max(5)]],
          allocatedToProject: [{
            value: (this.userDetails.allocatedToProject.allocation) ? this.userDetails.allocatedToProject.projectName : "",
            disabled: true
          }],
          percentageAllocation: [{
            value: (this.userDetails.allocatedToProject.allocation) ? this.userDetails.allocatedToProject.percentageAllocation : "",
            disabled: true
          }],
          selectedDomain: [""],
          customExp: [""],
          selectedPLC: [""],
          customExpPLC: [""],
          selectedSCADA: [""],
          customExpSCADA: [""],
          selectedDCS: [""],
          customExpDCS: [""],
          selectedHMI: [""],
          customExpHMI: [""],
          selectedOther: [""],
          customExpOther: [""],
          otherDomain: [""],
          otherDomainExp: [""],
          otherPLC: [""],
          otherPLCExp: [""],
          otherSCADA: [""],
          otherSCADAExp: [""],
          otherHMI: [""],
          otherHMIExp: [""],
          otherDCS: [""],
          otherDCSExp: [""],
          otherOTHER: [""],
          otherOTHERExp: [""],

        });
        this.filterData();
      }
    }, err => {
      if (err.status == 0) { this.router.navigate(['/asdasd']); }
      else if (err.status == 500) this.receivedData = [];
    })
  }
  formatLabelPercentage(value: number) {
    return value + '%'
  }
  formatLabelYears(value: number) {
    return value + "y"
  }
  removeDetails(id) {
    this.mainService.removeDetails(id).subscribe(value => {
      this.openSnackBar(value, 'Dismiss');
      this.addForm = this.fb.group({
        employeeId: ["", Validators.required],
        employeeName: ["", Validators.required],
        employeeEmail: ["", [Validators.required,Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/)]],
        contactNo: ["", Validators.required],
        jobLevel: ["", Validators.required],
        currentRole: ["", Validators.required],
        totalExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
        infosysExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
        controlSystemExperience: ["", [Validators.required, Validators.min(1), Validators.max(5)]],
        allocatedToProject: ["", Validators.required],
        percentageAllocation: ["", Validators.required],
        selectedDomain: [""],
        customExp: [""],
        selectedPLC: [""],
        customExpPLC: [""],
        selectedSCADA: [""],
        customExpSCADA: [""],
        selectedDCS: [""],
        customExpDCS: [""],
        selectedHMI: [""],
        customExpHMI: [""],
        selectedOther: [""],
        customExpOther: [""]

      });
      this.domainArray = this.scadaSkillArray = this.plcSkillArray = this.dcsSkillArray = this.hmiSkillArray = this.otherSkillArray;
    }, err => this.openSnackBar1(String(err.message), 'Dismiss'))
  }
  openSnackBar(message: any, action: string) {
    this._snackBar.open(message.message, action, {
      duration: 2000,
      verticalPosition: 'top'
    });
  }
  openSnackBar1(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
      verticalPosition: 'top'
    });
  }
}
