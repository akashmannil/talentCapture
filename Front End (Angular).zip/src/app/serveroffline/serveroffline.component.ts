import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-serveroffline',
  templateUrl: './serveroffline.component.html',
  styleUrls: ['./serveroffline.component.css']
})
export class ServerofflineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
