import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { map } from 'rxjs/operators';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { ActivatedRoute, Router } from '@angular/router';
import { MainService } from '../main.service';
import * as Chart from 'chart.js';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HashPipe } from '../hash.pipe';
@Component({
  selector: 'app-my-dashboard',
  templateUrl: './my-dashboard.component.html',
  styleUrls: ['./my-dashboard.component.css']
})
export class MyDashboardComponent implements OnInit {
  appDashboard;
  chartHoverFn(){
    // document.getElementById('projectAll').style.cursor="pointer";
  }
  detailsCardObject: any = { Entries: 0, SuperAdmin: 1, TotalAdmin: 1, TotalUsers: 2, jobLevelPlusRole: "Asd" };
  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true
  };
  access;
  handleClick(e) {
    let data = null;
    if (e.indexOf('Admins') > -1) { data = "Admin" }
    else if (e.indexOf('Super_Admin') > -1) { data = "SuperAdmin" }
    else if (e.indexOf('Users') > -1) { data = "User" }
    if (data)
      this.serv.getAccessData(data).subscribe(value => {
        if (value)
          this.openDialog(value, e);
      },
        err => this.openSnackBar(err.error.message,'Dismiss'))
    else {
      this.serv.getAllUsers().subscribe(value => {
        if (value)
          this.openDialog(value, e);
      }, err => this.openSnackBar(err.error.message,'Dismiss'))
    }
  }

  public barChartOptions1 = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      xAxes: [
        {
          display: false
        }
      ],
      yAxes: [
        {
          display: true
        }
      ]
    }
  };
  public barChartLabels = ['2006', '2007', '2008', '2009', '2010', '2011', '2012'];
  public barChartType = 'bar';
  public barChartLegend = true;
  public barChartLegend1 = false;
  public barChartData = [
    { data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A' },
    { data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B' },
  ];
  projectAllocationData: any = [{}];
  projectAllocationLabel: any = [];
  jobData: any = [{}];
  jobLabel: any = [];
  jobLabel1: any = [];
  cardData: any = [{}];
  cardLabel: any = [];
  cardDataLabel: any = [];
  dataCardData: any = [];
  dataCardLabel: any = [];
  allSkillsData: any = [{}];
  allSkillsLabel: any = [];
  loading: boolean = true;
  public pieChartLabels = ['Sales Q1', 'Sales Q2', 'Sales Q3', 'Sales Q4'];
  public pieChartData = [120, 150, 180, 90];
  public pieChartType = 'pie';

  detailsCard1;
  cards1;
  /** Based on the screen size, switch from standard to one column per row */
  cards = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(({ matches }) => {
      if (matches) {
        return [{ title: 'Domain', cols: 6, rows: 1, myOrder: 1, name: 'domainAverage' },
        { title: 'PLC Skills', cols: 6, rows: 1, myOrder: 2, name: 'plcAverage' },
        { title: 'SCADA Skills', cols: 6, rows: 1, myOrder: 3, name: 'scadaAverage' },
        { title: 'DCS Skills', cols: 6, rows: 1, myOrder: 4, name: 'dcsAverage' },
        { title: 'HMI Skills', cols: 6, rows: 1, myOrder: 5, name: 'hmiAverage' }
        ];
      }

      return [{ title: 'Domain', cols: 2, rows: 1, myOrder: 1, name: 'domainAverage' },
      { title: 'PLC Skills', cols:2, rows: 1, myOrder: 2, name: 'plcAverage' },
      { title: 'HMI Skills', cols: 2, rows: 1, myOrder: 5, name: 'hmiAverage' },
      { title: 'SCADA Skils', cols: 2, rows: 1, myOrder: 3, name: 'scadaAverage' },
      { title: 'DCS Skills', cols: 2, rows: 1, myOrder: 4, name: 'dcsAverage' }
      ];
    })
  );

  mobileView: boolean = false;
  detailsCard = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(({ matches }) => {
      let a: any = {}, b = [];
      if (matches && this.detailsCardObject.front) {
        Object.keys(this.detailsCardObject.front).forEach(v => {
          a = {}
          a.title = v;
          a.rows = 1;
          a.cols = 4;
          b.push(a);
        })
        this.mobileView = true;
        return b;
      }
      else if (!matches && this.detailsCardObject.front) {
        Object.keys(this.detailsCardObject.front).forEach(v => {
          a = {}
          a.title = v;
          a.rows = 1;
          a.cols = 1;
          b.push(a);
        })
        this.mobileView = false;
      }
      return b;
    })
  );
  constructor(private breakpointObserver: BreakpointObserver, private route: ActivatedRoute,
    private serv: MainService, public dialog: MatDialog, private _snackBar:MatSnackBar) {
  }
  displayData(e,title){
    if(title.indexOf('Name')>0)
    this.serv.getDetails(e).subscribe(value=>{
      this.openDialog2(value,'User Details')
    },err=>this.openSnackBar(err.error.message,'Dismiss'))
    else if((title.indexOf('Role')>-1)){
      this.serv.getUser('role',encodeURI(e)).subscribe(value=>{
        this.openDialog1(value,e+'(s)');
      },err=>this.openSnackBar(err.error.message,'Dismiss'))
    }
  }
  ngOnInit() {
    this.allSkillsData= [{}];
      this.allSkillsLabel= [];
    let hash:HashPipe=new HashPipe();
    this.access=hash.transform(sessionStorage.getItem('accessType'));
    this.jobLabel1 = this.jobLabel = [];
    this.route.params.subscribe(param => {
      this.appDashboard = param.id; 
      this.serv.getDashboardData(this.appDashboard).subscribe(value => {
        this.detailsCardObject = value;
        this.detailsCard = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
          map(({ matches }) => {
            let a: any = {}, b = [];
            if (matches) {
              Object.keys(this.detailsCardObject.front).forEach(v => {
                a = {};
                a.title = v;
                a.rows = 1;
                a.cols = 4;
                b.push(a);
              })
              this.mobileView = true;
              return b;
            }
            Object.keys(this.detailsCardObject.front).forEach(v => {
              a = {}
              a.title = v;
              a.rows = 1;
              a.cols = 1;
              b.push(a);
            })
            this.mobileView = false;
            return b;
          })
        );
        this.projectAllocationData[0].data = Object.values(this.detailsCardObject.projectAllocation);
        this.projectAllocationData[0].label = "Allocated Employee(s)"
        this.projectAllocationLabel = Object.keys(this.detailsCardObject.projectAllocation);
        this.cardLabel = Object.keys(this.detailsCardObject).map(asd => {
          if (asd.indexOf('Average') > 0) {
            let a = [], b = [];
            this.detailsCardObject[asd].forEach(v => {
              b.push(Object.keys(v).map(val => val)[0]);
              a.push(Object.values(v).map(val => val)[0]);
            });
            this.cardDataLabel.push(b);
            this.cardData.push(a);
            return asd;
          }
        }).filter(v => v);

        let jd = [];
        this.detailsCardObject.jobLevelPlusRole.forEach(val => {
          this.jobLabel.push(val.jobLevelPlusRole[0] + " " + val.jobLevelPlusRole.substr(1));
          jd.push(val.count);
        })
        this.jobData[0].data = jd;
        this.jobData[0].label = "No. of Employees";
        this.jobLabel1 = this.jobLabel.map(v => {
          return v.split(' ').map(a => a[0]).join('')[0] + " " + v.split(' ').map(a => a[0]).join('').substr(1);
        })


        this.detailsCard1 = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
          map(({ matches }) => {
            let a: any = {}, b = [];
            if (matches) {
              b.push({ title: 'Employee Name', rows: 1, cols: 4, value: this.detailsCardObject.employee.employeeName },
                { title: 'Role', rows: 1, cols: 4, value: this.detailsCardObject.employee.currentRole },
                { title: 'Total Experience', rows: 1, cols: 4, value: this.detailsCardObject.employee.totalExperience + "yrs" },
                { title: 'Infosys Experience', rows: 1, cols: 4, value: this.detailsCardObject.employee.infosysExperience + "yrs" });
              this.mobileView = true;
              return b;
            }
            else {
              b.push({ title: 'Employee Name', rows: 1, cols: 1, value: this.detailsCardObject.employee.employeeName },
                { title: 'Role', rows: 1, cols: 1, value: this.detailsCardObject.employee.currentRole },
                { title: 'Total Experience', rows: 1, cols: 1, value: this.detailsCardObject.employee.totalExperience + "yrs" },
                { title: 'Infosys Experience', rows: 1, cols: 1, value: this.detailsCardObject.employee.infosysExperience + "yrs" })
            }
            this.mobileView = false;
            return b;
          })
        );
        if (this.detailsCardObject.employee) {
          let count = 0, a = [], b = [], c = [];
          this.detailsCardObject.employee.domain.forEach(dom => {
            count = 0;
            this.cardDataLabel[0].find(aa => {
              if (dom.domain == aa) {
                a.push(dom.experience);
                b.push(this.cardData[1][count])
                c.push(aa);
              }
              count += 1;
            })
          })
          this.dataCardData.push([{ data: a, label: "Experience(in yrs)" }, { data: b, label: "Infy Avg Experience(in yrs)" }]);
          this.dataCardLabel.push(c);

          this.allSkillsData[0].data = [];
          this.allSkillsData[0].label = "Experience(in yrs)";

          a = [], b = [], c = [];
          this.detailsCardObject.employee.plcSkills.forEach(dom => {
            count = 0;
            this.cardDataLabel[1].find(aa => {
              if (dom.plcSkill == aa) {
                a.push(dom.experience);
                b.push(this.cardData[2][count])
                c.push(aa);
              }
              count += 1;
            })
          })
          a.forEach(v => this.allSkillsData[0].data.push(v))
          c.forEach(v => this.allSkillsLabel.push(v));
          this.dataCardData.push([{ data: a, label: "Experience(in yrs)" }, { data: b, label: "Infy Avg Experience(in yrs)" }]);
          this.dataCardLabel.push(c);

          a = [], b = [], c = [];
          this.detailsCardObject.employee.scadaSkills.forEach(dom => {
            count = 0;
            this.cardDataLabel[2].find(aa => {
              if (dom.scadaSkill == aa) {
                a.push(dom.experience);
                b.push(this.cardData[3][count])
                c.push(aa);
              }
              count += 1;
            })
          })
          a.forEach(v => this.allSkillsData[0].data.push(v))
          c.forEach(v => this.allSkillsLabel.push(v));
          this.dataCardData.push([{ data: a, label: "Experience(in yrs)" }, { data: b, label: "Infy Avg Experience(in yrs)" }]);
          this.dataCardLabel.push(c);

          a = [], b = [], c = [];
          this.detailsCardObject.employee.dcsSkills.forEach(dom => {
            count = 0;
            this.cardDataLabel[3].find(aa => {
              if (dom.dcsSkill == aa) {
                a.push(dom.experience);
                b.push(this.cardData[4][count])
                c.push(aa);
              }
              count += 1;
            })
          })
          a.forEach(v => this.allSkillsData[0].data.push(v))
          c.forEach(v => this.allSkillsLabel.push(v));
          this.dataCardData.push([{ data: a, label: "Experience(in yrs)" }, { data: b, label: "Infy Avg Experience(in yrs)" }]);
          this.dataCardLabel.push(c);


          a = [], b = [], c = [];
          this.detailsCardObject.employee.hmiSkills.forEach(dom => {
            count = 0;
            this.cardDataLabel[4].find(aa => {
              if (dom.hmiSkill == aa) {
                a.push(dom.experience);
                b.push(this.cardData[5][count])
                c.push(aa);
              }
              count += 1;
            })
          })
          a.forEach(v => this.allSkillsData[0].data.push(v))
          c.forEach(v => this.allSkillsLabel.push(v));
          this.dataCardData.push([{ data: a, label: "Experience(in yrs)" }, { data: b, label: "Infy Avg Experience(in yrs)" }]);
          this.dataCardLabel.push(c);






          this.cards1 = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
            map(({ matches }) => {
              if (matches) {
                return [{ title: 'Domain', cols: 6, rows: 1, myOrder: 1, name: 'domainAverage' },
                { title: 'All Skills', cols: 6, rows: 1, myOrder: 6, name: 'all' },
                { title: 'PLC Skills', cols: 6, rows: 1, myOrder: 2, name: 'plcAverage' },
                { title: 'SCADA Skills', cols: 6, rows: 1, myOrder: 3, name: 'scadaAverage' },
                { title: 'DCS Skills', cols: 6, rows: 1, myOrder: 4, name: 'dcsAverage' },
                { title: 'HMI Skills', cols: 6, rows: 1, myOrder: 5, name: 'hmiAverage' },
                ];
              }

              return [{ title: 'Domain', cols: 2, rows: 1, myOrder: 1, name: 'domainAverage' },
              { title: 'All Skills', cols: 2, rows: 1, myOrder: 6, name: 'all' },
              { title: 'PLC Skills', cols: 2, rows: 1, myOrder: 2, name: 'plcAverage' },
              { title: 'HMI Skills', cols: 2, rows: 1, myOrder: 5, name: 'hmiAverage' },
              { title: 'SCADA Skils', cols: 2, rows: 1, myOrder: 3, name: 'scadaAverage' },
              { title: 'DCS Skills', cols: 2, rows: 1, myOrder: 4, name: 'dcsAverage' },
              ];
            })
          );



        }
        // this.cardData[1]._chartjs=[{data:this.cardData[1],label:"Average Experience(in yrs)"}]
  
        this.loading = false;
      }, err => this.openSnackBar(err.error.message,'Dismiss'))
    })
  }
  openDialog(value: any, name: any): void {
    const dialogRef = this.dialog.open(DataViewer, {
      width: '70%',
      data: { value: value, name: name }
    });

    dialogRef.afterClosed().subscribe(result => {

      this.ngOnInit();
    });
  }
  public barChartColors = [
    { backgroundColor: 'teal' },
    { backgroundColor: 'tan' },
  ]
public barChartColors1 = [
  { backgroundColor: 'indigo' },
  { backgroundColor: 'tan' },
]
bgColorProject=[ { backgroundColor: 'gray' },
{ backgroundColor: 'maroon' }];
  openDialog1(value: any, name: any): void {
    const dialogRef = this.dialog.open(DataViewer, {
      width: '70%',
      data: { value: value, name: name }
    });

    // dialogRef.afterClosed().subscribe(result => {
     
    // });
  }
  openDialog2(value: any, name: any): void {
    const dialogRef = this.dialog.open(DataViewer, {
      width: '70%',
      data: { value: value, name: name }
    });

    // dialogRef.afterClosed().subscribe(result => {

    // });
  }
  public chartClickedEmployee({ event, active }: { event: MouseEvent, active: any }): void {
    if(active[0]){
    this.serv.getUser('role',encodeURI(this.jobLabel[active[0]._index].substr(2))).subscribe(value=>{
      this.openDialog1(value,this.jobLabel[active[0]._index].substr(2)+'(s)');
    },err=>this.openSnackBar(err.error.message,'Dismiss'))
  }
  }
  public chartClickedProject({ event, active }: { event: MouseEvent, active: any }): void {
    if(active[0]){
    this.serv.getUser('project',encodeURI(this.projectAllocationLabel[active[0]._index])).subscribe(value=>{
      this.openDialog1(value,'Employee(s) Allocated to '+this.projectAllocationLabel[active[0]._index].replace(/[ ]/g,'+'));
    },err=>this.openSnackBar(err.error.message,'Dismiss'))
  }
  }
  public chartClickedPLC({ event, active }: { event: MouseEvent, active: any }): void {
    if(active[0]){
    this.serv.getUser('plcSkills',encodeURI((!this.appDashboard)?this.cardDataLabel[1][active[0]._index]:
    this.dataCardLabel[1][active[0]._index]).replace(/[/]/g,'sLaSh')).subscribe(value=>{
      this.openDialog1(value,'Employee(s) having skill '+((!this.appDashboard)?
      this.cardDataLabel[1][active[0]._index]:this.dataCardLabel[1][active[0]._index]));
    },err=>this.openSnackBar(err.error.message,'Dismiss'))
  }
  }
  public chartClickedSCADA({ event, active }: { event: MouseEvent, active: any }): void {
    if(active[0]){
    this.serv.getUser('scadaSkills',encodeURI((!this.appDashboard)?this.cardDataLabel[2][active[0]._index]
    :this.dataCardLabel[2][active[0]._index]).replace(/[/]/g,'sLaSh')).subscribe(value=>{
      this.openDialog1(value,'Employee(s) having skill '+((!this.appDashboard)?this.cardDataLabel[2][active[0]._index]:
      this.dataCardLabel[2][active[0]._index]));
    },err=>this.openSnackBar(err.error.message,'Dismiss'))
  }
  }
  public chartClickedDCS({ event, active }: { event: MouseEvent, active: any }): void {
    if(active[0]){
    this.serv.getUser('dcsSkills',encodeURI((!this.appDashboard)?this.cardDataLabel[3][active[0]._index]:
    this.dataCardLabel[3][active[0]._index]).replace(/[/]/g,'sLaSh')).subscribe(value=>{
      this.openDialog1(value,'Employee(s) having skill '+((!this.appDashboard)?this.cardDataLabel[3][active[0]._index]:
      this.dataCardLabel[3][active[0]._index]));
    },err=>this.openSnackBar(err.error.message,'Dismiss'))
  }
  }
  public chartClickedHMI({ event, active }: { event: MouseEvent, active: any }): void {
    if(active[0]){
    this.serv.getUser('hmiSkills',encodeURI((!this.appDashboard)?this.cardDataLabel[4][active[0]._index]:
    this.dataCardLabel[4][active[0]._index]).replace(/[/]/g,'sLaSh')).subscribe(value=>{
      this.openDialog1(value,'Employee(s) having skill '+((!this.appDashboard)?this.cardDataLabel[4][active[0]._index]:
      this.dataCardLabel[4][active[0]._index]));
    },err=>this.openSnackBar(err.error.message,'Dismiss'))
  }
  }
  public chartClickedDomain({ event, active }: { event: MouseEvent, active: any }): void {
    if(active[0]){
    this.serv.getUser('domain',encodeURI((!this.appDashboard)?this.cardDataLabel[0][active[0]._index]
    :this.dataCardLabel[0][active[0]._index]).replace(/[/]/g,'sLaSh')).subscribe(value=>{
      this.openDialog1(value,'Employee(s) having domain '+((!this.appDashboard)?this.cardDataLabel[0][active[0]._index]:
      this.dataCardLabel[0][active[0]._index]));
    },err=>this.openSnackBar(err.error.message,'Dismiss'))
  }
  }
  public chartClickedAll({ event, active }: { event: MouseEvent, active: any }): void {
    if(active[0]){
    this.serv.getUser('all',encodeURI(this.allSkillsLabel[active[0]._index].replace(/[/]/g,'sLaSh'))).subscribe(value=>{
      this.openDialog1(value,'Employee(s) having skill '+(
        this.allSkillsLabel[active[0]._index]));
    },err=>this.openSnackBar(err.error.message,'Dismiss'))
  }
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
      verticalPosition: 'top'
    });
  }
}


@Component({
  selector: 'veiw-data',
  templateUrl: 'dataViewer.html',
})
export class DataViewer {
  context:CanvasRenderingContext2D;
  constructor(
    public dialogRef: MatDialogRef<DataViewer>,
    @Inject(MAT_DIALOG_DATA) public data: any, private serv: MainService, private _snackBar: MatSnackBar,
    private router:Router) {
    this.dataSource = data.value;
    this.access=sessionStorage.getItem('accessType');
    this.displayedColumns= ['employeeId', 'employeeName', 'emailId'];
    if(this.hash.transform(this.access)=='SuperAdmin'){
    this.displayedColumns= ['employeeId', 'employeeName', 'emailId','actions'];
    }
  }
  access;
  hash=new HashPipe();
  onNoClick(): void {
    this.dialogRef.close();
  }
  removeData(e) {
    this.serv.removeAccessData(e.employeeId).subscribe(value => {
      this.openSnackBar1(value, 'Dismiss');
      this.dataSource = this.dataSource.filter(v => v.employeeId != e.employeeId);
      this.dataSource = [...this.dataSource];
    },
      err => this.openSnackBar(err.error.message, 'Dismiss'))
  }
  handleClick(e){
    if(!(this.data.name=="App_Admins"||this.data.name=="App_Super_Admin"||this.data.name=="App_Users"))
    this.redirectTo('dashboard/'+e);
    this.dialogRef.close();
  }
  removeDetails(e) {
    this.serv.removeDetails(e.employeeId).subscribe(value => {
      this.openSnackBar1(value, 'Dismiss');
      this.dataSource = this.dataSource.filter(v => v.employeeId != e.employeeId);
      this.dataSource = [...this.dataSource];
    },
      err => this.openSnackBar(err.error.message, 'Dismiss'))
  }
  
  
  displayedColumns: string[];
  dataSource = [];
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
      verticalPosition: 'top'
    });
  }
  openSnackBar1(message: any, action: string) {
    this._snackBar.open(message.message, action, {
      duration: 2000,
      verticalPosition: 'top'
    });
  }
  redirectTo(uri: string) {
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
      this.router.navigate([uri]));
  }

}
