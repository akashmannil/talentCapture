import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';




@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  profile;
  url="http://localhost:1050/login";
  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.http.get(this.url).subscribe(value=>{
      console.log(value)
    },err=>console.log(err))
  }
}
