import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddDetailsComponent } from './add-details/add-details.component';
import { LoginComponent } from './login/login.component';
import { MyDashboardComponent } from './my-dashboard/my-dashboard.component';
import { LoginGuard } from './login.guard';
import { ServerofflineComponent } from './serveroffline/serveroffline.component';
import { MsalGuard } from '@azure/msal-angular';


const routes: Routes = [
  {path:'',component:AddDetailsComponent},
  {path:"login",component:LoginComponent,canActivate:[MsalGuard]},
  {path:"addDetails",component:AddDetailsComponent},
  {path:"dashboard",component:MyDashboardComponent,canActivate:[LoginGuard]},
  {path:'dashboard/:id',component:MyDashboardComponent,canActivate:[LoginGuard]},
  {path:'503',component:ServerofflineComponent},
  {path:"**",pathMatch:'full',redirectTo:'/503'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
