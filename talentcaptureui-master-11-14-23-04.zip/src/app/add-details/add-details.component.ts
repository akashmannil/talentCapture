import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { map, shareReplay, find } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { MainService } from '../main.service';
import { HashPipe } from '../hash.pipe';
@Component({
  selector: 'app-add-details',
  templateUrl: './add-details.component.html',
  styleUrls: ['./add-details.component.css']
})
export class AddDetailsComponent implements OnInit {
  @Input()
  testButton: boolean;
  selectedUser;
  loading: boolean = true;
  backbutton: boolean;
  access;
  domainArray: Array<any> = [];
  plcSkillArray: Array<any> = [];
  scadaSkillArray: Array<any> = [];
  dcsSkillArray: Array<any> = [];
  hmiSkillArray: Array<any> = [];
  otherSkillArray: Array<any> = [];
  selectedDomain;
  customExp;
  selectedPLC;
  customExpPLC;
  selectedSCADA;
  customExpSCADA;
  selectedDCS;
  customExpDCS;
  selectedHMI;
  customExpHMI;
  selectedOther;
  customExpOther;
  totalExp;
  infyExp;
  cseExp;
  viewDetailsClicked; //error
  panelOpenState;
  viewSetupDatabase;
  receivedData: any;
  receivedDataCopy: any;
  receiveData(e) {
    this.selectedUser = e;
    this.updateClicked = !this.updateClicked;
    this.viewDetailsClicked = !this.viewDetailsClicked;
  }
  decryptHash(key) {
    return this.hash.transform(sessionStorage.getItem(key))
  }
  handleAddDetails() {
    if (this.decryptHash('accessType') == 'SuperAdmin' || this.decryptHash('accessType') == 'Admin' || this.decryptHash('accessType') == 'User') {
      this.redirectTo(this.router.url);
      this.defaultClicked = true; this.viewAccess = false; this.selectedUser = null;
      this.updateClicked = false; this.viewDetailsClicked = false; this.viewSetupDatabase = false;
    }
    else {
      this.openSnackBar('Action not available for users', 'OK')
    }
  }
  redirectTo(uri: string) {
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
      this.router.navigate([uri]));
  }
  handleViewDetails() {
    if (this.decryptHash('accessType') == 'SuperAdmin' || this.decryptHash('accessType') == 'Admin') {
      this.defaultClicked = false; this.selectedUser = null;
      this.updateClicked = false; this.viewDetailsClicked = true; this.viewSetupDatabase = false;
    }
    else {
      this.openSnackBar('Action not available for users', 'OK')
    }
  }
  handleUpdateDetails() {
    if (this.decryptHash('accessType') == 'SuperAdmin' || this.decryptHash('accessType') == 'Admin') {
      this.defaultClicked = false; this.viewAccess = false; this.selectedUser = null;
      this.updateClicked = true; this.viewDetailsClicked = false; this.viewSetupDatabase = false;
    }
    else {
      this.openSnackBar('Action not available for users', 'OK')
    }
  }
  handleSetupTesting() {
    if (this.decryptHash('accessType') == 'SuperAdmin' || this.decryptHash('accessType') == 'Admin') {
      this.viewAccess = false; this.selectedUser = null; this.viewSetupDatabase = false; this.handleSetup()
    }
    else {
      this.openSnackBar('Action not available for users', 'OK')
    }
  }

  handleSetupDatabase() {
    if (this.decryptHash('accessType') == 'SuperAdmin') {
      this.viewSetupDatabase = true;
      this.viewAccess = false; this.selectedUser = null;
      this.viewDetailsClicked = false;
      this.updateClicked = false;
      this.defaultClicked = false;
    }
    else {
      this.openSnackBar('Action not available', 'OK')
    }
  }

  addForm;
  onSubmit() {
    this.addForm.value.domain = this.domainArray;
    this.addForm.value.plcSkills = this.plcSkillArray;
    this.addForm.value.scadaSkills = this.scadaSkillArray;
    this.addForm.value.dcsSkills = this.dcsSkillArray;
    this.addForm.value.hmiSkills = this.hmiSkillArray;
    this.addForm.value.otherSkills = this.otherSkillArray;
    this.addForm.value.allocatedToProject = {
      name: this.addForm.value.allocatedToProject,
      allocation: (this.addForm.value.allocatedToProject) ? true : false,
      percentageAllocation: this.addForm.value.percentageAllocation
    };
    this.mainService.addDetails(this.addForm.value).subscribe(value => {
      this.openSnackBar('Data Added Successfully', 'Dismiss');
    }, err => this.openSnackBar(err.message, 'Dismiss'))
  }
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
  defaultClicked: boolean = true;
  updateClicked: boolean = false;
  viewDetals: boolean = false;
  constructor(private fb: FormBuilder, private _snackBar: MatSnackBar, private breakpointObserver: BreakpointObserver,
    private mainService: MainService, private router: Router) {
  }
  sortData() {
    this.receivedData.domain.sort();
    this.receivedData.domain = this.receivedData.domain.filter(_ => _ != 'other' && _ != 'Other' && _ != 'Others' && _ != 'NA')
    this.receivedData.plcSkills = this.receivedData.plcSkills.filter(_ => _ != 'other' && _ != 'Other' && _ != 'Others' && _ != 'NA')
    this.receivedData.scadaSkills = this.receivedData.scadaSkills.filter(_ => _ != 'other' && _ != 'Other' && _ != 'Others' && _ != 'NA')
    this.receivedData.hmiSkills = this.receivedData.hmiSkills.filter(_ => _ != 'other' && _ != 'Other' && _ != 'Others' && _ != 'NA')
    this.receivedData.dcsSkills = this.receivedData.dcsSkills.filter(_ => _ != 'other' && _ != 'Other' && _ != 'Others' && _ != 'NA')
    this.receivedData.otherSkills = this.receivedData.otherSkills.filter(_ => _ != 'other' && _ != 'Other' && _ != 'Others' && _ != 'NA')
    this.receivedData.plcSkills.sort();
    this.receivedData.scadaSkills.sort();
    this.receivedData.dcsSkills.sort();
    this.receivedData.hmiSkills.sort();
    this.receivedData.otherSkills.sort();
    this.receivedData.domain.push('Others');
    this.receivedData.scadaSkills.push('Others');
    this.receivedData.plcSkills.push('Others');
    this.receivedData.hmiSkills.push('Others');
    this.receivedData.dcsSkills.push('Others');
    this.receivedData.otherSkills.push('Others');
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
      verticalPosition: 'top'
    });
  }
  childToggle(e) {
    e.toggle();
  }
  poppedDomain;
  addDomain(custom = false) {
    if (!custom) {
      this.domainArray.push({ domain: this.addForm.value.selectedDomain, experience: this.addForm.value.customExp });
      this.receivedData.domain = this.receivedData.domain.filter(v => v != this.addForm.value.selectedDomain);
    }
    else {
      this.domainArray.push({ domain: this.addForm.value.otherDomain, experience: this.addForm.value.otherDomainExp });
    }
  }
  removeDomain(domain) {
    this.domainArray = this.domainArray.filter(value => value.domain != domain);
    if (this.receivedDataCopy.domain.find(v => v == domain)) {
      this.receivedData.domain.push(domain);
      this.receivedData.domain.sort();
    }
  }
  addPLCSkill(custom = false) {
    if (!custom) {
      this.plcSkillArray.push({ plcSkill: this.addForm.value.selectedPLC, experience: this.addForm.value.customExpPLC });
      this.receivedData.plcSkills = this.receivedData.plcSkills.filter(v => v != this.addForm.value.selectedPLC);
    }
    else
      this.plcSkillArray.push({ plcSkill: this.addForm.value.otherPLC, experience: this.addForm.value.otherPLCExp });

  }
  removePLCSkill(skill) {
    this.plcSkillArray = this.plcSkillArray.filter(value => skill != value.plcSkill);
    if (this.receivedDataCopy.plcSkills.find(v => v == skill)) {
      this.receivedData.plcSkills.push(skill);
      this.receivedData.plcSkills.sort();
    }
  }
  addSCADASkill(custom = false) {
    if (!custom) {
      this.scadaSkillArray.push({ scadaSkill: this.addForm.value.selectedSCADA, experience: this.addForm.value.customExpSCADA })
      this.receivedData.scadaSkills = this.receivedData.scadaSkills.filter(v => v != this.addForm.value.selectedSCADA);
    }
    else
      this.scadaSkillArray.push({ scadaSkill: this.addForm.value.otherSCADA, experience: this.addForm.value.otherSCADAExp });

  }
  removeSCADASkill(skill) {
    this.scadaSkillArray = this.scadaSkillArray.filter(value => skill != value.scadaSkill);
    if (this.receivedDataCopy.scadaSkills.find(v => v == skill)) {
      this.receivedData.scadaSkills.push(skill);
      this.receivedData.scadaSkills.sort();
    }
  }
  addDCSSkill(custom = false) {
    if (!custom) {
      this.dcsSkillArray.push({ dcsSkill: this.addForm.value.selectedDCS, experience: this.addForm.value.customExpDCS });
      this.receivedData.dcsSkills = this.receivedData.dcsSkills.filter(v => v != this.addForm.value.selectedDCS);
    }
    else
      this.dcsSkillArray.push({ dcsSkill: this.addForm.value.otherDCS, experience: this.addForm.value.otherDCSExp });
  }
  removeDCSSkill(skill) {
    this.dcsSkillArray = this.dcsSkillArray.filter(value => skill != value.dcsSkill);
    if (this.receivedDataCopy.dcsSkills.find(v => v == skill)) {
      this.receivedData.dcsSkills.push(skill);
      this.receivedData.dcsSkills.sort();
    }
  }
  addHMISkill(custom = false) {
    if (!custom) {
      this.hmiSkillArray.push({ hmiSkill: this.addForm.value.selectedHMI, experience: this.addForm.value.customExpHMI });
      this.receivedData.hmiSkills = this.receivedData.hmiSkills.filter(v => v != this.addForm.value.selectedHMI);
    }
    else
      this.hmiSkillArray.push({ hmiSkill: this.addForm.value.otherHMI, experience: this.addForm.value.otherHMIExp });

  }
  removeHMISkill(skill) {
    this.hmiSkillArray = this.hmiSkillArray.filter(value => skill != value.hmiSkill);
    if (this.receivedDataCopy.hmiSkills.find(v => v == skill)) {
      this.receivedData.hmiSkills.push(skill);
      this.receivedData.hmiSkills.sort();
    }
  }
  addOtherSkill(custom = false) {
    if (!custom) {
      this.otherSkillArray.push({ otherSkill: this.addForm.value.selectedOther, experience: this.addForm.value.customExpOther })
      this.receivedData.otherSkills = this.receivedData.otherSkills.filter(v => v != this.addForm.value.selectedOther);
    }
    else
      this.otherSkillArray.push({ otherSkill: this.addForm.value.otherOTHER, experience: this.addForm.value.otherOTHERExp });
  }
  removeOtherSkill(skill) {
    this.otherSkillArray = this.otherSkillArray.filter(value => skill != value.otherSkill);
    if (this.receivedDataCopy.otherSkills.find(v => v == skill)) {
      this.receivedData.otherSkills.push(skill);
      this.receivedData.otherSkills.sort();
    }
  }
  hash: HashPipe = new HashPipe();
  ngOnInit() {
    this.testButton = (document.getElementById('testButton').getAttribute('value') == '0' ? false : true);
    this.addForm = this.fb.group({
      employeeId: ["", Validators.required],
      employeeName: ["", Validators.required],
      employeeEmail: ["", Validators.required],
      contactNo: ["", [Validators.required, Validators.min(1000000000), Validators.max(9999999999)]],
      jobLevel: ["", Validators.required],
      currentRole: ["", Validators.required],
      totalExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
      infosysExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
      controlSystemExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
      allocatedToProject: [{ value: "", disabled: true }],
      percentageAllocation: [{ value: "", disabled: true }],
      selectedDomain: [""],
      customExp: [""],
      selectedPLC: [""],
      customExpPLC: [""],
      selectedSCADA: [""],
      customExpSCADA: [""],
      selectedDCS: [""],
      customExpDCS: [""],
      selectedHMI: [""],
      customExpHMI: [""],
      selectedOther: [""],
      customExpOther: [""],
      otherDomain: [""],
      otherDomainExp: [""],
      otherPLC: [""],
      otherPLCExp: [""],
      otherSCADA: [""],
      otherSCADAExp: [""],
      otherHMI: [""],
      otherHMIExp: [""],
      otherDCS: [""],
      otherDCSExp: [""],
      otherOTHER: [""],
      otherOTHERExp: [""],
    });
    this.mainService.getDynamicData().subscribe(value => {
      this.receivedDataCopy = {}
      this.receivedData = value;
      this.receivedDataCopy.domain = this.receivedData.domain;
      this.receivedDataCopy.plcSkills = this.receivedData.plcSkills;
      this.receivedDataCopy.dcsSkills = this.receivedData.dcsSkills;
      this.receivedDataCopy.scadaSkills = this.receivedData.scadaSkills;
      this.receivedDataCopy.hmiSkills = this.receivedData.hmiSkills;
      this.sortData(); if (this.decryptHash('accessType') == 'SuperAdmin') {

        this.addForm = this.fb.group({
          employeeId: ["", Validators.required],
          employeeName: ["", Validators.required],
          employeeEmail: ["", Validators.required],
          contactNo: ["", [Validators.required, Validators.min(1000000000), Validators.max(9999999999)]],
          jobLevel: ["", Validators.required],
          currentRole: ["", Validators.required],
          totalExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
          infosysExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
          controlSystemExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
          allocatedToProject: [""],
          percentageAllocation: [{ value: "", disabled: false }],
          selectedDomain: [""],
          customExp: [""],
          selectedPLC: [""],
          customExpPLC: [""],
          selectedSCADA: [""],
          customExpSCADA: [""],
          selectedDCS: [""],
          customExpDCS: [""],
          selectedHMI: [""],
          customExpHMI: [""],
          selectedOther: [""],
          customExpOther: [""],
          otherDomain: [""],
          otherDomainExp: [""],
          otherPLC: [""],
          otherPLCExp: [""],
          otherSCADA: [""],
          otherSCADAExp: [""],
          otherHMI: [""],
          otherHMIExp: [""],
          otherDCS: [""],
          otherDCSExp: [""],
          otherOTHER: [""],
          otherOTHERExp: [""],
        });

      }
    }, err => {
      if (err.status == 0) { this.router.navigate(['/asdasd']); }
      else if (err.status == 500) this.receivedData = []
    })
    setTimeout(() => this.loading = false, 2000);
    this.access = this.hash.transform(sessionStorage.getItem('accessType'));
  }
  formatLabelPercentage(value: number) {
    return value + '%'
  }
  formatLabelYears(value: number) {
    return value + "y"
  }
  viewAccess: boolean = false;
  handleSetup() {
    if (document.getElementById('testButton').getAttribute('value') == '0') {
      this.openSnackBar('Please enable test mode to access this', 'OK')
      this.defaultClicked = true;
      this.updateClicked = false;
      this.viewDetailsClicked = false;
    }
    else {
      this.defaultClicked = false;
      this.updateClicked = false;
      this.viewDetailsClicked = false;
    }
  }
}
