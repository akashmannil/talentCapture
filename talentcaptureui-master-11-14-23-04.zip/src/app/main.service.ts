import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HashPipe } from './hash.pipe';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class MainService {
  url: string = "http://localhost:1050/"
  constructor(private http: HttpClient) { }

  addDetails(data) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.post(this.url + 'details/add', data, { withCredentials: true });
    return this.http.post(this.url + 'test/' + '/details/add', data, { withCredentials: true });
  }
  getDetails(data) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'details/' + data, { withCredentials: true });
    return this.http.get(this.url + 'test/' + '/details/' + data, { withCredentials: true });
  }
  removeDetails(empId) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.delete(this.url + 'details/' + empId, { withCredentials: true });
    return this.http.delete(this.url + 'test/' + 'details/' + empId, { withCredentials: true });
  }
  updateDetails(user) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.put(this.url + 'details/update', user, { withCredentials: true });
    return this.http.put(this.url + 'test/' + 'details/update', user, { withCredentials: true });
  }
  getDynamicData() {
    if (document.getElementById('testButton').getAttribute('value') == '0')
    return this.http.get(this.url + 'details/getdynamicdata', { withCredentials: true })
    return this.http.get(this.url + 'test/details/getdynamicdata', { withCredentials: true })
  }
  setupTestDB(number) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'setupDb/' + (number - 1), { withCredentials: true })
    return this.http.get(this.url + 'test/setupDb/' + (number - 1), { withCredentials: true })
  }
  getDashboardData(data = null) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'details/dashboardData/' + data, { withCredentials: true })
    return this.http.get(this.url + 'test/details/dashboardData/' + data, { withCredentials: true })
  }
  viewDetails(id) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'details/' + id, { withCredentials: true });
    return this.http.get(this.url + 'test/details/' + id, { withCredentials: true });
  }
  getNotifications() {
    let hash = new HashPipe();
    if (document.getElementById('testButton').getAttribute('value') == '0') {
      if (hash.transform(sessionStorage.getItem('accessType')) == 'SuperAdmin')
        return this.http.get(this.url + 'action/getnotifications/SuperAdmin', { withCredentials: true });
      else if (hash.transform(sessionStorage.getItem('accessType')) == 'Admin')
        return this.http.get(this.url + 'action/getnotifications/Admin', { withCredentials: true });
    }
    else {
      if (hash.transform(sessionStorage.getItem('accessType')) == 'SuperAdmin')
        return this.http.get(this.url + 'test/action/getnotifications/SuperAdmin', { withCredentials: true });
      else if (hash.transform(sessionStorage.getItem('accessType')) == 'Admin')
        return this.http.get(this.url + 'test/action/getnotifications/Admin', { withCredentials: true });
    }

  }
  resolveRequest(id, action) {
    action = action ? 'approve' : 'reject';
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.delete(this.url + 'action/resolve/' + id + '/' + action, { withCredentials: true });
    return this.http.delete(this.url + 'test/action/resolve/' + id + '/' + action, { withCredentials: true });
  }
  addRequest(data) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.post(this.url + 'action/add', data, { withCredentials: true });
    return this.http.post(this.url + 'test/action/add', data, { withCredentials: true });
  }
  getAccessData(data) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'accessData/' + data, { withCredentials: true });
    return this.http.get(this.url + 'test/accessData/' + data, { withCredentials: true });
  }
  removeAccessData(data) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.delete(this.url + 'accessData/' + data, { withCredentials: true });
    return this.http.delete(this.url + 'test/accessData/' + data, { withCredentials: true });
  }
  getAllUsers() {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'getAllUsers/getAll', { withCredentials: true });
    return this.http.get(this.url + 'test/getAllUsers/getAll', { withCredentials: true });
  }
  getUser(type, id) {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'getUser/' + type + '/' + id, { withCredentials: true });
    return this.http.get(this.url + 'test/getUser/' + type + '/' + id, { withCredentials: true });
  }
  getCurrentUser() {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'getCurrentUser/', { withCredentials: true });
    return this.http.get(this.url + 'test/getCurrentUser/', { withCredentials: true });
  }
  tryfn() {
    if (document.getElementById('testButton').getAttribute('value') == '0')
      return this.http.get(this.url + 'login/login/login', { withCredentials: true });
    return this.http.get(this.url + 'test/login/login/login', { withCredentials: true });
  }
  tryfn1(a) {
    // if (document.getElementById('testButton').getAttribute('value') == '0')
    return this.http.get(this.url + 'login/login/login/' + a, { withCredentials: true });
    // return this.http.get(this.url + 'test/login/login/login',{withCredentials:true});
  }
}

// redirectTo(uri:string){
//   this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
//   this.router.navigate([uri]));
// }
