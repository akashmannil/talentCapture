import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SetupDbComponent } from './setup-db.component';

describe('SetupDbComponent', () => {
  let component: SetupDbComponent;
  let fixture: ComponentFixture<SetupDbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetupDbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetupDbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
