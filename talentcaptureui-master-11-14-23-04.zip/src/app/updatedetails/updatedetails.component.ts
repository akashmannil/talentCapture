import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { MainService } from '../main.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-updatedetails',
  templateUrl: './updatedetails.component.html',
  styleUrls: ['./updatedetails.component.css']
})
export class UpdatedetailsComponent implements OnInit {
  @Input()
  userDetails;
  @Output()
  toggleButton:EventEmitter<any>=new EventEmitter();
  domainArray: Array<any> = [];
  plcSkillArray: Array<any> = [];
  scadaSkillArray: Array<any> = [];
  dcsSkillArray: Array<any> = [];
  hmiSkillArray: Array<any> = [];
  otherSkillArray: Array<any> = [];
  selectedDomain;
  customExp;
  selectedPLC;
  customExpPLC;
  selectedSCADA;
  customExpSCADA;
  selectedDCS;
  customExpDCS;
  selectedHMI;
  customExpHMI;
  selectedOther;
  customExpOther;
  sidenav; backbutton; totalExp; infyExp; cseExp;//error
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
  domain = ['infrastructure top-level domain (ARPA)'
    , 'generic top-level domains (gTLD)'
    , 'generic-restricted top-level domains (grTLD)'
    , 'sponsored top-level domains (sTLD)'
    , 'country code top-level domains (ccTLD)'
    , 'test top-level domains (tTLD)']
  addForm = this.fb.group({
    employeeId: ["", Validators.required],
    employeeName: ["", Validators.required],
    employeeEmail: ["", Validators.required],
    contactNo: ["", Validators.required],
    jobLevel: ["", Validators.required],
    currentRole: ["", Validators.required],
    totalExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
    infosysExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
    controlSystemExperience: ["", [Validators.required, Validators.min(1), Validators.max(5)]],
    allocatedToProject: ["", Validators.required],
    percentageAllocation: ["", Validators.required],
    selectedDomain: [""],
    customExp: [""],
    selectedPLC: [""],
    customExpPLC: [""],
    selectedSCADA: [""],
    customExpSCADA: [""],
    selectedDCS: [""],
    customExpDCS: [""],
    selectedHMI: [""],
    customExpHMI: [""],
    selectedOther: [""],
    customExpOther: [""]

  });
  emitFn(){
    this.toggleButton.emit(true);
  }
  onSubmit() {
    this.addForm.value.domain = this.domainArray;
    this.addForm.value.plcSkills = this.plcSkillArray;
    this.addForm.value.scadaSkills = this.scadaSkillArray;
    this.addForm.value.dcsSkills = this.dcsSkillArray;
    this.addForm.value.hmiSkills = this.hmiSkillArray;
    this.addForm.value.otherSkills = this.otherSkillArray;
    this.addForm.value.allocatedToProject={
      name:this.addForm.value.allocatedToProject,
      allocation: (this.addForm.value.allocatedToProject)? true:false,
      percentageAllocation:this.addForm.value.percentageAllocation
    };
    this.mainService.updateDetails(this.addForm.value).subscribe(value=>{
      this.openSnackBar(value,'Dismiss');
      this.redirectTo(this.router.url);
    },err=>{this.openSnackBar1(err.message,'Dismiss')}
)
  }
  redirectTo(uri:string){
    this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
    this.router.navigate([uri]));
  }

  constructor(private fb: FormBuilder,private breakpointObserver:BreakpointObserver,private mainService:MainService,
    private router:Router,private _snackBar:MatSnackBar) { 
    }
  receivedData:any;
  sortData() {
    this.receivedData.domain.sort();
    this.receivedData.domain=this.receivedData.domain.filter(_=>_!='other'&&_!='Other'&&_!='Others'&&_!='NA')
    this.receivedData.plcSkills=this.receivedData.plcSkills.filter(_=>_!='other'&&_!='Other'&&_!='Others'&&_!='NA')
    this.receivedData.scadaSkills=this.receivedData.scadaSkills.filter(_=>_!='other'&&_!='Other'&&_!='Others'&&_!='NA')
    this.receivedData.hmiSkills=this.receivedData.hmiSkills.filter(_=>_!='other'&&_!='Other'&&_!='Others'&&_!='NA')
    this.receivedData.dcsSkills=this.receivedData.dcsSkills.filter(_=>_!='other'&&_!='Other'&&_!='Others'&&_!='NA')
    this.receivedData.otherSkills=this.receivedData.otherSkills.filter(_=>_!='other'&&_!='Other'&&_!='Others'&&_!='NA')
    this.receivedData.plcSkills.sort();
    this.receivedData.scadaSkills.sort();
    this.receivedData.dcsSkills.sort();
    this.receivedData.hmiSkills.sort();
    this.receivedData.otherSkills.sort();
  }
  
  addDomain() {
    this.domainArray.push({ domain: this.addForm.value.selectedDomain, experience: this.addForm.value.customExp });
    this.receivedData.domain=this.receivedData.domain.filter(v=>v!=this.addForm.value.selectedDomain);
  }
  removeDomain(domain) {
    this.domainArray = this.domainArray.filter(value => value.domain != domain);
    this.receivedData.domain.push(domain);
    this.receivedData.domain.sort();
  }
  addPLCSkill() {
    this.plcSkillArray.push({ plcSkill: this.addForm.value.selectedPLC, experience: this.addForm.value.customExpPLC });
    this.receivedData.plcSkills=this.receivedData.plcSkills.filter(v=>v!=this.addForm.value.selectedPLC);
  }
  removePLCSkill(skill) {
    this.plcSkillArray = this.plcSkillArray.filter(value => skill != value.plcSkill);
    this.receivedData.plcSkills.push(skill);
    this.receivedData.plcSkills.sort();
  }
  addSCADASkill() {
    this.scadaSkillArray.push({ scadaSkill: this.addForm.value.selectedSCADA, experience: this.addForm.value.customExpSCADA })
    this.receivedData.scadaSkills=this.receivedData.scadaSkills.filter(v=>v!=this.addForm.value.selectedSCADA);  
  }
  removeSCADASkill(skill) {
    this.scadaSkillArray = this.scadaSkillArray.filter(value => skill != value.scadaSkill);
    this.receivedData.scadaSkills.push(skill);
    this.receivedData.scadaSkills.sort();
  }
  addDCSSkill() {
    this.dcsSkillArray.push({ dcsSkill: this.addForm.value.selectedDCS, experience: this.addForm.value.customExpDCS });
    this.receivedData.dcsSkills=this.receivedData.dcsSkills.filter(v=>v!=this.addForm.value.selectedDCS);  
  }
  removeDCSSkill(skill) {
    this.dcsSkillArray = this.dcsSkillArray.filter(value => skill != value.dcsSkill);
    this.receivedData.dcsSkills.push(skill);
    this.receivedData.dcsSkills.sort();
  }
  addHMISkill() {
    this.hmiSkillArray.push({ hmiSkill: this.addForm.value.selectedHMI, experience: this.addForm.value.customExpHMI });
    this.receivedData.hmiSkills=this.receivedData.hmiSkills.filter(v=>v!=this.addForm.value.selectedHMI);
  }
  removeHMISkill(skill) {
    this.hmiSkillArray = this.hmiSkillArray.filter(value => skill != value.hmiSkill);
    this.receivedData.hmiSkills.push(skill);
    this.receivedData.hmiSkills.sort();
  }
  addOtherSkill() {
    this.otherSkillArray.push({ otherSkill: this.addForm.value.selectedOther, experience: this.addForm.value.customExpOther })
    this.receivedData.otherSkills=this.receivedData.otherSkills.filter(v=>v!=this.addForm.value.selectedOther);

  }
  removeOtherSkill(skill) {
    this.otherSkillArray = this.otherSkillArray.filter(value => skill != value.otherSkill);
    this.receivedData.otherSkills.push(skill);
    this.receivedData.otherSkills.sort();
  }
  ngOnInit() {
    this.mainService.getDynamicData().subscribe(value => {
      this.receivedData = value;
      this.sortData();
      if(this.userDetails){
        this.domainArray=this.userDetails.domain;
        this.plcSkillArray=this.userDetails.plcSkills;
        this.scadaSkillArray=this.userDetails.scadaSkills;
        this.dcsSkillArray=this.userDetails.dcsSkills;
        this.hmiSkillArray=this.userDetails.hmiSkills;
        this.otherSkillArray=this.userDetails.otherSkills;
        this.addForm = this.fb.group({
          employeeId: [this.userDetails.employeeId, Validators.required],
          employeeName: [this.userDetails.employeeName, Validators.required],
          employeeEmail: [this.userDetails.employeeEmail, Validators.required],
          contactNo: [this.userDetails.contactNo, Validators.required],
          jobLevel: [this.userDetails.jobLevel, Validators.required],
          currentRole: [this.userDetails.currentRole, Validators.required],
          totalExperience: [this.userDetails.totalExperience, [Validators.required, Validators.min(1), Validators.max(10)]],
          infosysExperience: [this.userDetails.infosysExperience, [Validators.required, Validators.min(1), Validators.max(10)]],
          controlSystemExperience: [this.userDetails.controlSystemExperience, [Validators.required, Validators.min(1), Validators.max(5)]],
          allocatedToProject: [(this.userDetails.allocatedToProject.allocation)?this.userDetails.allocatedToProject.projectName:"",
             Validators.required],
          percentageAllocation: [(this.userDetails.allocatedToProject.allocation)?this.userDetails.allocatedToProject.percentageAllocation:"", Validators.required],
          selectedDomain: [""],
          customExp: [""],
          selectedPLC: [""],
          customExpPLC: [""],
          selectedSCADA: [""],
          customExpSCADA: [""],
          selectedDCS: [""],
          customExpDCS: [""],
          selectedHMI: [""],
          customExpHMI: [""],
          selectedOther: [""],
          customExpOther: [""]
      
        });
      }
    }, err =>{
    if(err.status==0){this.router.navigate(['/asdasd']);}
    else if(err.status==500)this.receivedData=[];
  })
  }
  formatLabelPercentage(value: number) {
    return value + '%'
  }
  formatLabelYears(value: number) {
    return value + "y"
  }
  removeDetails(id){
    this.mainService.removeDetails(id).subscribe(value=>{
      this.openSnackBar(value,'Dismiss');
      this.addForm = this.fb.group({
        employeeId: ["", Validators.required],
        employeeName: ["", Validators.required],
        employeeEmail: ["", Validators.required],
        contactNo: ["", Validators.required],
        jobLevel: ["", Validators.required],
        currentRole: ["", Validators.required],
        totalExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
        infosysExperience: ["", [Validators.required, Validators.min(1), Validators.max(10)]],
        controlSystemExperience: ["", [Validators.required, Validators.min(1), Validators.max(5)]],
        allocatedToProject: ["", Validators.required],
        percentageAllocation: ["", Validators.required],
        selectedDomain: [""],
        customExp: [""],
        selectedPLC: [""],
        customExpPLC: [""],
        selectedSCADA: [""],
        customExpSCADA: [""],
        selectedDCS: [""],
        customExpDCS: [""],
        selectedHMI: [""],
        customExpHMI: [""],
        selectedOther: [""],
        customExpOther: [""]
    
      });
      this.domainArray=this.scadaSkillArray=this.plcSkillArray=this.dcsSkillArray=this.hmiSkillArray=this.otherSkillArray;
    },err=>this.openSnackBar1(String(err.message),'Dismiss'))
  }
  openSnackBar(message: any, action: string) {
    this._snackBar.open(message.message, action, {
      duration: 2000,
      verticalPosition: 'top'
    });
  }
  openSnackBar1(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
      verticalPosition: 'top'
    });
  }
}
