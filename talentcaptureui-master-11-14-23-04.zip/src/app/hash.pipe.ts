import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'hash'
})
export class HashPipe implements PipeTransform {

  transform(value): any {
    if (value) {
      let key = Number(Number(value.split('k')[1]));
      let subtr = Number(value.split('k')[2])
      let count = -1;
      return value.split('k')[0].split('a').map(a => {
        return String.fromCharCode(subtr - Number(a) + key + (count += 1))
      }).join('');
    }
  }

}
