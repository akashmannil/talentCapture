import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DemoMaterialModule } from './material_module'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MyDashboardComponent, DataViewer } from './my-dashboard/my-dashboard.component';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { LayoutModule } from '@angular/cdk/layout';
import { TcNavbarComponent, DialogOverviewExampleDialog } from './tc-navbar/tc-navbar.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { LoginComponent } from './login/login.component';
import { ServerofflineComponent } from './serveroffline/serveroffline.component';
import { AddDetailsComponent } from './add-details/add-details.component';
import { LoadingIconComponent } from './loading-icon/loading-icon.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { ChartsModule } from 'ng2-charts';

// import { MsalModule, MsalInterceptor } from '@azure/msal-angular';
import { HttpClientModule } from '@angular/common/http';
import { ViewdetailsComponent } from './viewdetails/viewdetails.component';
import { UpdatedetailsComponent } from './updatedetails/updatedetails.component';
import { SetupTestComponent } from './setup-test/setup-test.component';
import { UnderscorePipe } from './underscore.pipe';
import { AccessRequestComponent } from './access-request/access-request.component';
import { HashPipe } from './hash.pipe';
import { SetupDbComponent } from './setup-db/setup-db.component';


@NgModule({
  declarations: [
    AppComponent,
    MyDashboardComponent,
    TcNavbarComponent,
    LoginComponent,
    ServerofflineComponent,
    AddDetailsComponent,
    LoadingIconComponent,
    ViewdetailsComponent,
    UpdatedetailsComponent,
    SetupTestComponent,
    UnderscorePipe,
    DialogOverviewExampleDialog,
    AccessRequestComponent,
    DataViewer,
    HashPipe,
    SetupDbComponent
  ],
  imports: [ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    DemoMaterialModule,
    MatGridListModule,
    MatCardModule,
    MatMenuModule,
    MatIconModule,
    MatButtonModule,
    LayoutModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    FormsModule,
    ChartsModule,
    HttpClientModule,
  ],
  providers: [
  ],
  entryComponents:[DialogOverviewExampleDialog,DataViewer],
  bootstrap: [AppComponent]
})
export class AppModule { }
