import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { map, shareReplay, sample } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { MainService } from '../main.service';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-setup-test',
  templateUrl: './setup-test.component.html',
  styleUrls: ['./setup-test.component.css']
})
export class SetupTestComponent implements OnInit {
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
  backbutton: boolean = false;
  @Output()
  toggleButton: EventEmitter<any> = new EventEmitter();
  emitFn() {
    this.toggleButton.emit(true);
  }
  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
      verticalPosition: 'top'
    });
  }
  constructor(private breakpointObserver: BreakpointObserver, private mainService: MainService,
    private _snackBar: MatSnackBar) { }
  samples;
  ngOnInit() {
  }
  onSubmit() {
    this.mainService.setupTestDB(this.samples).subscribe((a) => {
      this.openSnackBar('DB Setup Successful', 'Dismiss');
    }, err => {
      this.openSnackBar('Some Error Occured', 'Dismiss')
    })
    this.handleChange.emit(true);
  }
  @Output()
  handleChange = new EventEmitter<any>();
}
